=== Isaor Quill ===
Contributors: isaor
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.1
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: blog, one-column, two-columns, custom-colors, custom-menu, editor-style, featured-images, full-site-editing, block-patterns, translation-ready, sticky-post, threaded-comments, wide-blocks, rtl-language-support

A clean, minimal block theme for writers, bloggers, and journals.

== Description ==

Isaor Quill is a clean, minimal block theme built for writers, bloggers, and journals. It focuses on comfortable reading, generous typography, and fast, lightweight pages.

Fully powered by the block editor and the Site Editor, it works out of the box with no page builders, no tracking, and no bundled plugins. Isaor Quill is accessible, translation ready, and responsive on every screen.

Features:

* Full Site Editing support with editable header and footer template parts.
* A refined, readable typography system using system fonts (no external font requests).
* A warm, neutral color palette with light and accent tones.
* Block patterns for a hero header, a posts grid, and a featured quote.
* Templates for posts, pages, archives, search, and 404.
* Accessible skip links and visible keyboard focus states.
* No tracking, no external calls, and no data collection.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and choose the theme zip file, then click Install Now.
3. Click Activate to use your new theme right away.
4. Navigate to Appearance > Editor to customize templates, colors, and typography.

== Frequently Asked Questions ==

= Does this theme collect any user data? =

No. Isaor Quill does not track users, does not make external calls, and does not collect or store any personal data.

= Does the theme load external fonts? =

No. Isaor Quill uses system font stacks only, so no fonts are fetched from remote servers.

= Does the theme require any plugins? =

No. Isaor Quill works entirely with the WordPress block editor and Site Editor. No plugins are required or bundled.

= Is the theme compatible with the Site Editor? =

Yes. Isaor Quill is a block theme. You can edit templates, template parts, colors, and typography directly in Appearance > Editor.

== Changelog ==

= 1.0.1 =
* Removed Theme URI and custom block style registration for WordPress.org review compliance.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.1 =
Review-readiness update for WordPress.org submission.

= 1.0.0 =
Initial release of Isaor Quill.

== Copyright ==

Isaor Quill WordPress Theme, (C) 2026 isaor
Isaor Quill is distributed under the terms of the GNU GPL version 2 or later.

This program is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation, either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

== Resources ==

Isaor Quill bundles no third-party images, fonts, icons, or code libraries.
All theme code is original work by the theme author and is licensed under the
GNU General Public License v2 or later.

The theme uses only system font stacks (via CSS), which are provided by the
user's operating system and are not distributed with the theme.

The screenshot.png is an original design created by the theme author, licensed
under GNU GPL v2 or later.
