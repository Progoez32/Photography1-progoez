<?php
/**
 * Title: Posts Grid
 * Slug: isaor-quill/posts-grid
 * Categories: query, posts
 * Block Types: core/query
 * Description: A responsive three-column grid of recent posts with featured images, titles, and dates.
 *
 * @package Isaor_Quill
 * @since 1.0.0
 */
?>
<!-- wp:query {"query":{"perPage":6,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false},"layout":{"type":"default"}} -->
<div class="wp-block-query"><!-- wp:post-template {"layout":{"type":"grid","columnCount":3,"minimumColumnWidth":null},"style":{"spacing":{"blockGap":"var:preset|spacing|50"}}} -->
<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"4/3","style":{"border":{"radius":"6px"}}} /-->

<!-- wp:post-title {"isLink":true,"fontSize":"large"} /-->

<!-- wp:post-date {"fontSize":"small","textColor":"contrast-secondary"} /-->
<!-- /wp:post-template --></div>
<!-- /wp:query -->
