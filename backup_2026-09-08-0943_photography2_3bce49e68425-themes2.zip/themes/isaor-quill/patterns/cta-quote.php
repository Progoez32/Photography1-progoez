<?php
/**
 * Title: Featured Quote
 * Slug: isaor-quill/cta-quote
 * Categories: text, featured
 * Description: A large centered pull quote to highlight a key idea or testimonial.
 *
 * @package Isaor_Quill
 * @since 1.0.0
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:pullquote {"textAlign":"center"} -->
<figure class="wp-block-pullquote has-text-align-center"><blockquote><p><?php esc_html_e( 'The first draft is just you telling yourself the story.', 'isaor-quill' ); ?></p><cite><?php esc_html_e( 'A note to writers', 'isaor-quill' ); ?></cite></blockquote></figure>
<!-- /wp:pullquote --></div>
<!-- /wp:group -->
