<?php
/**
 * Isaor Quill functions and definitions.
 *
 * @package Isaor_Quill
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! function_exists( 'isaor_quill_setup' ) ) :
	/**
	 * Set up theme defaults and register support for various WordPress features.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function isaor_quill_setup() {
		// Make the theme available for translation.
		load_theme_textdomain( 'isaor-quill', get_template_directory() . '/languages' );

		// Enqueue editor styles so the block editor matches the front end.
		add_editor_style( 'style.css' );
	}
endif;
add_action( 'after_setup_theme', 'isaor_quill_setup' );

if ( ! function_exists( 'isaor_quill_enqueue_styles' ) ) :
	/**
	 * Enqueue the theme stylesheet on the front end.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function isaor_quill_enqueue_styles() {
		wp_enqueue_style(
			'isaor-quill-style',
			get_stylesheet_uri(),
			array(),
			wp_get_theme()->get( 'Version' )
		);
	}
endif;
add_action( 'wp_enqueue_scripts', 'isaor_quill_enqueue_styles' );
