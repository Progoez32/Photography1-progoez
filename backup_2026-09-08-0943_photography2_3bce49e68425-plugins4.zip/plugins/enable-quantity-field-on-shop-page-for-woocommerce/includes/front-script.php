<?php

if ( ! defined( 'ABSPATH' ) ) exit;

if (!class_exists('ISTWQFS_frontend')) {

	class ISTWQFS_frontend {

		protected static $ISTWQFS_frontend_instance;

		public static function ISTWQFS_frontend_instance() {

            if ( ! isset( self::$ISTWQFS_frontend_instance ) && ! ( self::$ISTWQFS_frontend_instance instanceof ISTWQFS_frontend ) ) {
                self::$ISTWQFS_frontend_instance = new ISTWQFS_frontend;
                self::$ISTWQFS_frontend_instance->init();
            }

            return self::$ISTWQFS_frontend_instance;
        }

        
        public function ISTWQFS_add_qty_fields($html, $product) {
            $istwqfs_quantity_label = get_option( 'istwqfs_quantity_label', 'Quantity:' );
            $istwqfs_qty_label_font_color = get_option( 'istwqfs_qty_label_font_color', '#000000' );
            $istwqfs_qty_label_font_weight = get_option( 'istwqfs_qty_label_font_weight', '400' );
            $istwqfs_qty_label_font_size = get_option( 'istwqfs_qty_label_font_size', '18' );
            $istwqfs_qty_label_enable = get_option( 'istwqfs_qty_label_enable' );

            if ( $product && $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() && ! $product->is_sold_individually() ) {

                ob_start();

                ?>
                <form action="<?php echo esc_url( $product->add_to_cart_url() ); ?>" class="cart istwqfs-shop-cart" method="post" enctype="multipart/form-data">
                    <?php echo woocommerce_quantity_input( array(), $product, false ); ?>
                    <button type="submit" data-quantity="1" data-product_id="<?php echo $product->get_id(); ?>" class="button alt ajax_add_to_cart add_to_cart_button product_type_simple istwqfs-add-to-cart"><?php echo esc_html( $product->add_to_cart_text() ); ?></button>
                    <p class='istwqfs-confirm-add'></p>
                </form>
                <?php 
                
                $html = ob_get_clean();
            }
            return $html;
        }

        function ISTWQFS_quantity_input_args( $args, $product ) {
            if ( is_singular( 'product' ) ) {
                $args['input_value']    = 1;    
            }
            $args['max_value']  = $product->stock_quantity;     
            $args['min_value']  = 1;    
            $args['step']       = 1;    
            return $args;
        }


        function ISTWQFS_qty_label_css() {
            $istwqfs_quantity_label = get_option( 'istwqfs_quantity_label', 'Quantity:' );
            $istwqfs_qty_label_font_color = get_option( 'istwqfs_qty_label_font_color', '#000000' );
            $istwqfs_qty_label_font_weight = get_option( 'istwqfs_qty_label_font_weight', '400' );
            $istwqfs_qty_label_font_size = get_option( 'istwqfs_qty_label_font_size', '18' );
            $istwqfs_qty_label_enable = get_option( 'istwqfs_qty_label_enable' );
            
            if($istwqfs_qty_label_enable == 'enable') {
                ?>
                <style>
                    .istwqfs-shop-cart .quantity:before {
                        content:"<?php esc_html_e( $istwqfs_quantity_label, ISTWQFS_DOMAIN ); ?>";
                        margin-right: 10px;
                        color: <?php esc_html_e( $istwqfs_qty_label_font_color, ISTWQFS_DOMAIN ); ?>;
                        font-size: <?php esc_html_e( $istwqfs_qty_label_font_size, ISTWQFS_DOMAIN ); ?>px;
                        font-weight: <?php esc_html_e( $istwqfs_qty_label_font_weight, ISTWQFS_DOMAIN ); ?>;
                    }
                </style>
                <?php
            }    
        }


        private function init() {
        	if(get_option('istwqfs_qty_field_enable', 'enable') == 'enable') {
                add_filter( 'woocommerce_loop_add_to_cart_link', array( $this, 'ISTWQFS_add_qty_fields' ), 10, 2 );
                add_filter( 'woocommerce_quantity_input_args', array( $this, 'ISTWQFS_quantity_input_args' ), 10, 2 );
                add_action('wp_footer', array( $this, 'ISTWQFS_qty_label_css' ));
            }
        }
	}
	ISTWQFS_frontend::ISTWQFS_frontend_instance();
}