<?php 

if ( ! defined( 'ABSPATH' ) ) exit;

if (!class_exists('ISTWQFS_menu')) {

	class ISTWQFS_menu {

		protected static $ISTWQFS_instance;

		public static function ISTWQFS_instance() {

            if ( ! isset( self::$ISTWQFS_instance ) && ! ( self::$ISTWQFS_instance instanceof ISTWQFS_menu ) ) {
                self::$ISTWQFS_instance = new ISTWQFS_menu;
                self::$ISTWQFS_instance->init();
            }

            return self::$ISTWQFS_instance;
        }

        function ISTWQFS_submenu_page() {
           add_submenu_page( 'woocommerce', 'Quantity Field ', 'Quantity Field on Shop Page', 'manage_options', 'istwqfs-quantity-field', array($this, 'ISTWQFS_callback'));
        }
        
        function ISTWQFS_callback() {
        	?>
            
        	<div class="wrap">
                <?php if(isset($_REQUEST['save']) && $_REQUEST['save'] == 'success') { ?>
                    <div class="istwqfs-settings-saved">
                        <img src="<?php echo ISTWQFS_PLUGIN_DIR; ?>/assets/images/check-mark.png" alt="check-icon">
                        <span>Settings Saved Successfully.</span>
                    </div>
                <?php } ?>
                <div class="istwqfs_container">
                	<form method="post">
                	 	<?php wp_nonce_field( 'ISTWQFS_meta_save', 'ISTWQFS_meta_save_nounce' ); ?>
                	 	<ul class="tabs tabs-basic">
                	 		<li class="active" data-tab="tab-default">
                                <a href="#" onclick="return false;"><?php esc_html_e( 'Quantity Field', ISTWQFS_DOMAIN ); ?></a>
                            </li>
                            <span class="indicator"></span>
                	 	</ul>
                	 	<div id="tab-default" class="tab-content active">
                	 		<div class="istwqfs_subcontainer">
                	 			<h2 class="istwqfs_header"><?php esc_html_e( 'General Settings', ISTWQFS_DOMAIN ); ?></h2>
                	 			<div class="istwqfs_group">
                                    <div class="istwqfs_label"><?php esc_html_e( 'Enable Quantity Field', ISTWQFS_DOMAIN ); ?></div>
                                    <div class="istwqfs_label_data">
                                        <input type="checkbox" name="istwqfs_qty_field_enable" value="enable" <?php if(get_option('istwqfs_qty_field_enable', 'enable') == 'enable' ) { echo 'checked'; } ?>>
                                    </div>
                                </div>
                	 		</div>
                	 		<div class="istwqfs_subcontainer">
                	 			<h2 class="istwqfs_header"><?php esc_html_e( 'Quantity Label Settings', ISTWQFS_DOMAIN ); ?></h2>
                                <div class="istwqfs_group">
                                    <div class="istwqfs_label"><?php esc_html_e( 'Enable Quantity Label', ISTWQFS_DOMAIN ); ?></div>
                                    <div class="istwqfs_label_data">
                                        <input type="checkbox" name="istwqfs_qty_label_enable" value="enable" <?php if(get_option('istwqfs_qty_label_enable') == 'enable' ) { echo 'checked'; } ?>>
                                    </div>
                                </div>
                	 			<div class="istwqfs_group">
                                    <div class="istwqfs_label"><?php esc_html_e( 'Quantity Label', ISTWQFS_DOMAIN ); ?></div>
                                    <div class="istwqfs_label_data">
                                        <?php $istwqfs_quantity_label = get_option('istwqfs_quantity_label', 'Quantity:'); ?>
                                        <input type="text" name="istwqfs_quantity_label" value="<?php esc_html_e( $istwqfs_quantity_label, ISTWQFS_DOMAIN ); ?>">
                                    </div>
                                </div>
                                <div class="istwqfs_group">
                                    <div class="istwqfs_label"><?php esc_html_e( 'Quantity Label Font Color', ISTWQFS_DOMAIN ); ?></div>
                                    <div class="istwqfs_label_data">
                                        <?php
                                        $istwqfs_qty_label_font_color = get_option('istwqfs_qty_label_font_color', '#000000');
                                        ?>
                                        <input type="text" class="color-picker" data-alpha="true" data-default-color="<?php esc_html_e( $istwqfs_qty_label_font_color, ISTWQFS_DOMAIN ); ?>" name="istwqfs_qty_label_font_color" value="<?php esc_html_e( $istwqfs_qty_label_font_color, ISTWQFS_DOMAIN ); ?>"/>
                                    </div>
                                </div>
                                <div class="istwqfs_group">
                                    <div class="istwqfs_label"><?php esc_html_e( 'Quantity Label Font Weight', ISTWQFS_DOMAIN ); ?></div>
                                    <div class="istwqfs_label_data">
                                        <?php $istwqfs_qty_label_font_weight = get_option('istwqfs_qty_label_font_weight', '400'); ?>
                                        <input type="number" name="istwqfs_qty_label_font_weight" value="<?php esc_html_e( $istwqfs_qty_label_font_weight, ISTWQFS_DOMAIN ); ?>">
                                        <span class="istwqfs_long_desc"><b>(You can get more specific by assigning a numerical weight value. Normal font weight is 400, and fonts work in multiples of 100.)</b></span>
                                    </div>
                                </div>
                                <div class="istwqfs_group">
                                    <div class="istwqfs_label"><?php esc_html_e( 'Quantity Label Font Size', ISTWQFS_DOMAIN ); ?></div>
                                    <div class="istwqfs_label_data">
                                        <?php $istwqfs_qty_label_font_size = get_option('istwqfs_qty_label_font_size', '18'); ?>
                                        <input type="number" name="istwqfs_qty_label_font_size" value="<?php esc_html_e( $istwqfs_qty_label_font_size, ISTWQFS_DOMAIN ); ?>">
                                        <span><b>(font size is in px, just enter number)</b></span>
                                    </div>
                                </div>
                	 		</div>
                             <div class="istwqfs_subcontainer">
                	 			<h2 class="istwqfs_header"><?php esc_html_e( 'Other Settings', ISTWQFS_DOMAIN ); ?></h2>
                	 			<div class="istwqfs_group">
                                    <div class="istwqfs_label"><?php esc_html_e( 'Product Added Message', ISTWQFS_DOMAIN ); ?></div>
                                    <div class="istwqfs_label_data">
                                        <?php $istwqfs_product_added_message = get_option('istwqfs_product_added_message', 'Product has been added to your cart'); ?>
                                        <input type="text" class="istwqfs_long_input_text" name="istwqfs_product_added_message" value="<?php esc_html_e( $istwqfs_product_added_message, ISTWQFS_DOMAIN ); ?>">
                                    </div>
                                </div>
                	 		</div>
                	 	</div>

                	 	<input type="hidden" name="action" value="istwqfs_save_option">
                        <input type="submit" value="Save changes" name="submit" class="button-primary" id="istwqfs_btn_space">
                	</form>
                </div>
        	</div>
        	<?php
        }


        function ISTWQFS_save_options() {
            if( current_user_can('administrator') ) {
                if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'istwqfs_save_option') {
                    if(!isset( $_POST['ISTWQFS_meta_save_nounce'] ) || !wp_verify_nonce( $_POST['ISTWQFS_meta_save_nounce'], 'ISTWQFS_meta_save' ) ) {

                        echo 'Sorry, your nonce did not verify.';

                        exit;
                    } else {

                        if(isset($_REQUEST['istwqfs_qty_field_enable']) && $_REQUEST['istwqfs_qty_field_enable'] == 'enable' ) {
                            $istwqfs_qty_field_enable = 'enable';
                        } else {
                            $istwqfs_qty_field_enable = 'disable';
                        }
                        update_option('istwqfs_qty_field_enable', $istwqfs_qty_field_enable, 'yes'); //Quantity Field Enable

                        if(isset($_REQUEST['istwqfs_qty_label_enable']) && $_REQUEST['istwqfs_qty_label_enable'] == 'enable' ) {
                            $istwqfs_qty_label_enable = 'enable';
                        } else {
                            $istwqfs_qty_label_enable = 'disable';
                        }
                        update_option('istwqfs_qty_label_enable', $istwqfs_qty_label_enable, 'yes'); //Quantity Label Enable

                        $istwqfs_quantity_label = sanitize_text_field( $_REQUEST['istwqfs_quantity_label'] );
                        update_option('istwqfs_quantity_label', $istwqfs_quantity_label, 'yes'); //Quantity Field label

                        $istwqfs_qty_label_font_color = sanitize_text_field( $_REQUEST['istwqfs_qty_label_font_color'] );
                        update_option('istwqfs_qty_label_font_color', $istwqfs_qty_label_font_color, 'yes'); //Quantity Field font color

                        $istwqfs_qty_label_font_weight = sanitize_text_field( $_REQUEST['istwqfs_qty_label_font_weight'] );
                        update_option('istwqfs_qty_label_font_weight', $istwqfs_qty_label_font_weight, 'yes'); //Quantity Field font weight

                        $istwqfs_qty_label_font_size = sanitize_text_field( $_REQUEST['istwqfs_qty_label_font_size'] );
                        update_option('istwqfs_qty_label_font_size', $istwqfs_qty_label_font_size, 'yes'); //Quantity Field font size

                        $istwqfs_product_added_message = sanitize_text_field( $_REQUEST['istwqfs_product_added_message'] );
                        update_option('istwqfs_product_added_message', $istwqfs_product_added_message, 'yes'); //Product added message

                        $url = admin_url( 'admin.php?page=istwqfs-quantity-field&save=success');
                        wp_redirect($url);
                    }
                }
            }
        }

		private function init() {
			add_action( 'admin_menu',  array($this, 'ISTWQFS_submenu_page'));
            add_action( 'init',  array($this, 'ISTWQFS_save_options'));
		}
	}
	ISTWQFS_menu::ISTWQFS_instance();
}