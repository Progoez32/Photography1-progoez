<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Plugin Verification And Error Message
 */
function ISTWQFS_ADMIN_NOTICE() {
    if ( get_transient( get_current_user_id() . 'istwqfserror' ) ) {

      	deactivate_plugins( ISTWQFS_BASE_NAME );

      	delete_transient( get_current_user_id() . 'istwqfserror' );

      	echo '<div id="message" class="error notice is-dismissible"><p><strong>WC Quantity Field On Shop Page</strong> plugin is deactivated because it require <a href="plugin-install.php?tab=search&s=woocommerce">WooCommerce</a> plugin installed and activated.</p></div>';
    }
}
add_action( 'admin_notices', 'ISTWQFS_ADMIN_NOTICE');

//Load Admin Side Script
function ISTWQFS_admin_style_script() {
	wp_enqueue_style( 'ISTWQFS_admin_style', ISTWQFS_PLUGIN_DIR . '/assets/css/backend-style.css', false, '1.0.0' );
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker-alpha', ISTWQFS_PLUGIN_DIR . '/assets/js/wp-color-picker-alpha.js', array( 'wp-color-picker' ), '1.0.0', true ); //Color Picker jQuery
}
add_action( 'admin_enqueue_scripts', 'ISTWQFS_admin_style_script');

//Load Front Side Script
function ISTWQFS_front_style_script() {
	wp_enqueue_style( 'ISTWQFS_front_style', ISTWQFS_PLUGIN_DIR . '/assets/css/front-style.css', false, '1.0.0' ); 
	wp_enqueue_script( 'ISTWQFS_front_script', ISTWQFS_PLUGIN_DIR . '/assets/js/frontend-script.js',array('jquery') );
	
	$istwqfs_product_added_message = get_option('istwqfs_product_added_message', 'Product has been added to your cart');
	
	$ISTWQFS_js_variables = array(
			'istwqfs_product_added_message' => esc_html( $istwqfs_product_added_message, ISTWQFS_DOMAIN ),
		);
	wp_localize_script( 'ISTWQFS_front_script', 'ISTWQFS_js_variables', $ISTWQFS_js_variables );

}
add_action( 'wp_enqueue_scripts', 'ISTWQFS_front_style_script');