<?php
/**
 * Plugin Name: Enable Quantity Field On Shop Page for WooCommerce
 * Plugin URI: https://wordpress.org/plugins/enable-quantity-field-on-shop-page-for-woocommerce/
 * Description: This plugin allows you to Create Quantity Field on WooCommerce Shop Page and Product Category Pages...
 * Author: Ista Techie
 * Version: 1.0.0
 * Tested up to: 5.9
 * WC tested up to: 5.9
 * Text Domain: enable-quantity-field-on-shop-page-for-woocommerce
 * Author URI: https://istatechie.com/
 */


// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'ISTWQFS' ) ) :

	/**
     * Main ISTWQFS Class.
     *
     * @since 1.0
     */

	final class ISTWQFS {

		protected static $ISTWQFS_instance;

		public static function ISTWQFS_instance() {

            if ( ! isset( self::$ISTWQFS_instance ) && ! ( self::$ISTWQFS_instance instanceof ISTWQFS ) ) {
                self::$ISTWQFS_instance = new ISTWQFS;
                self::$ISTWQFS_instance->setup_constants();
                self::$ISTWQFS_instance->includes();
            }

            return self::$ISTWQFS_instance;
        }

        private function setup_constants() {
            /*Plugin name.*/
            if (!defined('ISTWQFS_PLUGIN_NAME')) {
                define('ISTWQFS_PLUGIN_NAME', 'WC Quantity Field On Shop Page');
            }

            /*Plugin version.*/
            if (!defined('ISTWQFS_PLUGIN_VERSION')) {
                define('ISTWQFS_PLUGIN_VERSION', '1.0.0');
            }

            /*Plugin Folder Path.*/
            if ( ! defined( 'ISTWQFS_PLUGIN_DIR' ) ) {
                define( 'ISTWQFS_PLUGIN_DIR', plugins_url('', __FILE__) );
            }

            /*Plugin Root File.*/
            if (!defined('ISTWQFS_PLUGIN_FILE')) {
                define('ISTWQFS_PLUGIN_FILE', __FILE__);
            }

            /*Plugin Basename.*/
            if (!defined('ISTWQFS_BASE_NAME')) {
                define('ISTWQFS_BASE_NAME', plugin_basename(ISTWQFS_PLUGIN_FILE));
            }

            /*Plugin Domain.*/
            if (!defined('ISTWQFS_DOMAIN')) {
                define('ISTWQFS_DOMAIN', 'istwqfs');
            }
        }

        function __construct() {
            include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
            //check plugin activted or not
            add_action('admin_init', array($this, 'ISTWQFS_plugin_status'));
        }

        function ISTWQFS_plugin_status() {
            if ( ! ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) ) {
                set_transient( get_current_user_id() . 'istwqfserror', 'message' );
            }
        }

        private function includes() {
        	include_once ('includes/scripts.php');
            include_once ('includes/admin/backend-script.php');
            include_once ('includes/front-script.php');
        }
	}
    add_action('plugins_loaded', array('ISTWQFS', 'ISTWQFS_instance'));
endif; // End if class_exists check.

function ISTQUANTITYFIELD() {
    return ISTWQFS::ISTWQFS_instance();
}

// Get ISTQUANTITYFIELD Running.
ISTQUANTITYFIELD();