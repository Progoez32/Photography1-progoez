jQuery(document).ready(function() {

	jQuery('body').on('click', '.istwqfs-add-to-cart', function() {
    var istwqfs_product_added_message = ISTWQFS_js_variables.istwqfs_product_added_message;
    var itemAdded = jQuery(this).closest(".istwqfs-shop-cart").find(".istwqfs-confirm-add");
    itemAdded.hide();
    itemAdded.text(istwqfs_product_added_message);
    itemAdded.show();
  });

  jQuery("form.istwqfs-shop-cart").on("change", "input.qty", function() {

   	jQuery(this.form).find("[data-quantity]").attr("data-quantity", this.value); 

  });

  jQuery('body').on("adding_to_cart", function(response) {
		jQuery("a.added_to_cart").remove();
  });

});