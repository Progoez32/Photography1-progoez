=== Enable Quantity Field On Shop Page for WooCommerce ===
Contributors: istatechie
Tags: woocommerce, quantity field, shop page, shop, quantity
Donate link: https://www.paypal.com/paypalme/sbeladiya
Requires at least: 4.5
Tested up to: 5.9
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows adding quantity field on the shop page and product category pages with simple plugin settings.

== Description ==
This is a light plugin that adds a quantity field on the shop page for all products. Herewith this plugin, you have plenty of options to customize fields as well as success messages.

Woocommerce Quantity Field On Shop Page plugin comes with the following options:

* Enable/Disable Quantity Fields
* Enable/Disable Quantity Label
* Custom Quantity Label
* Quantity Lable Color
* Quantity Label Font Weight
* Quantity Label Font Size
* Custom Product Added Message

== Installation ==
###Install From WordPress Dashboard

1. log in to your the admin panel
2. Navigate to Plugins -> Add New
3. Search **Enable Quantity Field On Shop Page for WooCommerce**
4. Click install and activate respectively.

### Manual Install From WordPress Dashboard

If your server is not connected to the Internet, then you can use this method-

1. Download the plugin by clicking on the red button above. A ZIP file will be downloaded.
2. log in to your site\'s admin panel and navigate to Plugins -> Add New -> Upload.
3. Click choose file, select the plugin file and click install

### Install Using FTP

If you are unable to use any of the methods due to internet connectivity and file permission issues, then you can use this method-

1. Download the plugin by clicking on the red button above. A ZIP file will be downloaded.
2. Unzip the file.
3. Launch your favorite FTP client. Such as FileZilla, FireFTP, CyberDuck etc. If you are a more advanced user, then you can use SSH too.
4. Upload the folder to `wp-content/plugins/`
5. Log in to your WordPress dashboard.
6. Navigate to Plugins -> Installed
7. Activate the plugin

== Frequently Asked Questions ==
= Where is the settings page? =
You can find it under WooCommerce -> Quantity Field On Shop Page

= Will this work with other eCommerce plugins? =
This plugin will only work with Woocommerce Plugin.

== Screenshots ==
1. Plugin Settings Location
2. Plugin Settings Page
3. Frontend View of Plugin in Action

== Changelog ==
= 1.0.0 =
* Initial release.